alter table orders add column if not exists advance_required numeric default 0, add column if not exists advance_paid bool default false, add column if not exists advance_ref text;
insert into app_text(key,value) values('pay_cod','on'),('pay_ep','on'),('pay_jc','on'),('advance_mode','off'),('advance_value','0') on conflict do nothing;
create or replace function place_order(p_items jsonb,p_cust jsonb,p_coupon text default null) returns bigint
language plpgsql security definer set search_path=public as $$
declare pr profiles; it jsonb; p products; k product_packs; q int; u numeric; sub numeric:=0; ln jsonb:='[]'; city text:=p_cust->>'city';
 dfee numeric; disc numeric:=0; cc coupons; oid bigint; pay text:=coalesce(p_cust->>'payment','COD'); units numeric; nm text; wsok bool; pid bigint; adv numeric:=0; am text; av numeric;
begin
 if auth.uid() is null then raise exception 'Login required'; end if;
 if coalesce((select value from app_text where key='maintenance'),'')='on' and not is_admin() then raise exception 'Dukan band hai. Please try later.'; end if;
 if jsonb_array_length(p_items) not between 1 and 60 then raise exception 'Bad cart'; end if;
 select * into pr from profiles where id=auth.uid();
 wsok:=(pr.type='wholesale' and pr.status='approved');
 for it in select value from jsonb_array_elements(p_items) loop
  q:=(it->>'qty')::int; pid:=nullif(it->>'pack_id','null')::bigint; if q<1 or q>1000 then raise exception 'Bad quantity'; end if;
  select * into p from products where id=(it->>'id')::bigint for update;
  if not found then raise exception 'Product not found'; end if;
  nm:=p.name_en;
  if pid is not null then
   select * into k from product_packs where id=pid and product_id=p.id and active;
   if not found then raise exception 'Pack size not available'; end if;
   if k.wholesale_only and not wsok then raise exception 'This pack is for approved dukan buyers only'; end if;
   u:=coalesce(k.price_override,round(k.qty*k.rate_per_unit,2)); units:=q*k.qty;
   nm:=p.name_en||' ('||coalesce(nullif(k.label,''),initcap(k.kind))||' '||k.qty||' '||k.unit||')';
  else
   units:=q; u:=p.retail_price;
   if wsok and q>=p.wholesale_moq then u:=case when q>=p.wholesale_moq*2 then round(p.wholesale_price*(100-setting('tier2_pct'))/100) else p.wholesale_price end; end if;
   u:=least(u,coalesce((select min(price) from deals where product_id=p.id and active and now() between starts_at and ends_at),u));
  end if;
  if p.stock_qty<units then raise exception 'Out of stock: %',p.name_en; end if;
  update products set stock_qty=stock_qty-units where id=p.id;
  sub:=sub+u*q; ln:=ln||jsonb_build_array(jsonb_build_object('id',p.id,'name',nm,'qty',q,'price',u,'pack_id',pid,'kg',units));
 end loop;
 if sub<setting('min_order') then raise exception 'Minimum order is Rs. %',setting('min_order'); end if;
 dfee:=case when sub>=setting('free_over') then 0 when setting('fee_'||city) is not null then setting('fee_'||city) when city='DG Khan' then setting('delivery_dgkhan')
  when city in('Multan','Lahore','Bahawalpur','Faisalabad','Rawalpindi','Sialkot','Gujranwala') then setting('delivery_punjab') else setting('delivery_other') end;
 if p_coupon is not null and sub>=500 then
  select * into cc from coupons where code=upper(p_coupon) and active;
  if found then disc:=case cc.kind when 'flat' then cc.value else least(cc.max,round(sub*cc.value/100)) end;
  elsif exists(select 1 from profiles where ref_code=upper(p_coupon) and id<>auth.uid()) then disc:=100; end if;
 end if;
 if pay like 'Udhaar%' then pay:=case when wsok then 'Udhaar' else 'COD' end;
 elsif pay not in('COD','Easypaisa','JazzCash') then pay:='COD'; end if;
 if pay='COD' and coalesce((select value from app_text where key='pay_cod'),'on')='off' then raise exception 'Cash on delivery is not available right now. Please choose another payment method.'; end if;
 if pay='Easypaisa' and coalesce((select value from app_text where key='pay_ep'),'on')='off' then raise exception 'Easypaisa is not available right now.'; end if;
 if pay='JazzCash' and coalesce((select value from app_text where key='pay_jc'),'on')='off' then raise exception 'JazzCash is not available right now.'; end if;
 am:=coalesce((select value from app_text where key='advance_mode'),'off'); av:=coalesce(nullif((select value from app_text where key='advance_value'),'')::numeric,0);
 if pay='COD' then adv:=case am when 'fixed' then av when 'percent' then round((sub-disc+dfee)*av/100) when 'delivery' then dfee else 0 end; adv:=least(greatest(adv,0),sub-disc+dfee); end if;
 insert into orders(user_id,name,phone,city,area,address,payment,items,subtotal,delivery,discount,coupon,total,advance_required,advance_ref)
 values(auth.uid(),left(p_cust->>'name',80),left(p_cust->>'phone',20),city,left(p_cust->>'area',60),left(p_cust->>'address',300),
  pay,ln,sub,dfee,disc,upper(p_coupon),sub-disc+dfee,adv,left(p_cust->>'advance_ref',60)) returning id into oid;
 return oid;
end$$;
revoke all on function place_order from public;
grant execute on function place_order to authenticated;
notify pgrst, 'reload schema';
