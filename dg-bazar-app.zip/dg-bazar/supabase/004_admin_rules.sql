-- Run after setup_all.sql. Completes admin rules: blocking, audit log, role lock, delete rights, price sanity.
alter table profiles add column if not exists blocked bool default false;
create table if not exists admin_log(id bigint generated always as identity primary key,at timestamptz default now(),admin_id uuid,action text,detail text);
alter table admin_log enable row level security;
drop policy if exists al_sel on admin_log; create policy al_sel on admin_log for select using(is_admin());

create or replace function log_admin() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null or not is_admin() then return new; end if;
 if tg_table_name='orders' and (new.status is distinct from old.status or new.tracking_no is distinct from old.tracking_no) then
  insert into admin_log(admin_id,action,detail) values(auth.uid(),'order #'||new.id,'status '||old.status||' to '||new.status||coalesce(', courier '||new.tracking_no,''));
 elsif tg_table_name='profiles' and (new.status is distinct from old.status or new.blocked is distinct from old.blocked) then
  insert into admin_log(admin_id,action,detail) values(auth.uid(),'user '||coalesce(new.email,new.phone,''),'status '||old.status||' to '||new.status||', blocked '||coalesce(new.blocked::text,'false'));
 elsif tg_table_name='products' and (new.retail_price is distinct from old.retail_price or new.wholesale_price is distinct from old.wholesale_price or new.stock_qty is distinct from old.stock_qty) then
  insert into admin_log(admin_id,action,detail) values(auth.uid(),'product '||new.name_en,'price '||old.retail_price||'/'||old.wholesale_price||' to '||new.retail_price||'/'||new.wholesale_price||', stock '||old.stock_qty||' to '||new.stock_qty);
 end if;
 return new;
end$$;
drop trigger if exists t_log_o on orders; create trigger t_log_o after update on orders for each row execute function log_admin();
drop trigger if exists t_log_p on profiles; create trigger t_log_p after update on profiles for each row execute function log_admin();
drop trigger if exists t_log_pr on products; create trigger t_log_pr after update on products for each row execute function log_admin();

create or replace function guard_role() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.role is distinct from old.role and auth.uid() is not null then raise exception 'Role cannot be changed from the app'; end if;
 if new.id=auth.uid() and coalesce(new.blocked,false) then raise exception 'You cannot block yourself'; end if;
 return new;
end$$;
drop trigger if exists t_guard_role on profiles; create trigger t_guard_role before update on profiles for each row execute function guard_role();

create or replace function block_check() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if exists(select 1 from profiles where id=new.user_id and blocked) then raise exception 'Your account is blocked. Contact DG Bazar.'; end if;
 return new;
end$$;
drop trigger if exists t_block on orders; create trigger t_block before insert on orders for each row execute function block_check();

drop policy if exists o_del on orders; create policy o_del on orders for delete using(is_admin());
drop policy if exists p_del on profiles; create policy p_del on profiles for delete using(is_admin() and role<>'admin');
drop policy if exists st_del on storage.objects; create policy st_del on storage.objects for delete to authenticated using(bucket_id='products' and is_admin());
alter table products drop constraint if exists price_ok;
alter table products add constraint price_ok check(retail_price>0 and wholesale_price>0 and wholesale_price<=retail_price);
