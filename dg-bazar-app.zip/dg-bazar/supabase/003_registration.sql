-- Run after 002_production.sql. Registration details + email OTP support.
alter table profiles add column if not exists full_name text, add column if not exists email text,
 add column if not exists address text, add column if not exists city text;
create unique index if not exists profiles_email_key on profiles(lower(email)) where email is not null;

create or replace function profiles_guard() returns trigger language plpgsql security definer set search_path=public as $$
declare ph text; em text;
begin
 select nullif(phone,''),email into ph,em from auth.users where id=new.id;
 new.email:=coalesce(em,new.email);
 new.phone:=coalesce(ph,left(regexp_replace(coalesce(new.phone,''),'\D','','g'),15));   -- email users: contact phone (unverified)
 -- role comes ONLY from the verified auth identity (OTP phone or OTP email), never from client data
 new.role:=case when ph='923158120199' or em='admin@dg-bazar.pk' then 'admin' else 'customer' end;
 new.ref_code:='DG'||upper(substr(replace(new.id::text,'-',''),1,5));
 new.status:=case when new.role='admin' or new.type<>'wholesale' then 'approved' else 'pending' end;
 return new;
end$$;
