create or replace function shop_open() returns bool language plpgsql stable security definer set search_path=public as $$
declare t text:=coalesce((select value from app_text where key='maintenance'),'off'); a text:=coalesce((select value from app_text where key='auto_hours'),'off');
 o time:=coalesce(nullif((select value from app_text where key='open_time'),''),'09:00')::time; c time:=coalesce(nullif((select value from app_text where key='close_time'),''),'22:00')::time;
 d text:=coalesce((select value from app_text where key='closed_days'),''); n timestamp:=now() at time zone 'Asia/Karachi'; tm time:=(now() at time zone 'Asia/Karachi')::time;
begin
 if t='on' then return false; end if;
 if a<>'on' then return true; end if;
 if d<>'' and extract(dow from n)::int::text = any(string_to_array(d,',')) then return false; end if;
 if o<=c then return tm>=o and tm<c; else return tm>=o or tm<c; end if;
end$$;
create or replace function hours_check() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if not shop_open() and not is_admin() then raise exception 'Dukan band hai (shop is closed). Please order during opening hours.'; end if;
 return new;
end$$;
drop trigger if exists t_hours on orders; create trigger t_hours before insert on orders for each row execute function hours_check();
grant execute on function shop_open() to anon, authenticated;
