-- Full admin control: settings, cancel+restock, role management, admin repair.
create table if not exists settings(key text primary key,value numeric not null);
insert into settings values('delivery_dgkhan',99),('delivery_punjab',199),('delivery_other',250),('free_over',3000),('tier2_pct',3),('min_order',0) on conflict do nothing;
alter table settings enable row level security;
drop policy if exists s_sel on settings; create policy s_sel on settings for select using(true);
drop policy if exists s_all on settings; create policy s_all on settings for all using(is_admin()) with check(is_admin());
create or replace function setting(k text) returns numeric language sql stable security definer set search_path=public as $$select value from settings where key=k$$;

alter table orders drop constraint if exists orders_status_check;
alter table orders add constraint orders_status_check check(status in('Pending','Packed','Shipped','Delivered','Cancelled'));
create or replace function restock_cancel() returns trigger language plpgsql security definer set search_path=public as $$
declare it jsonb;
begin
 if new.status='Cancelled' and old.status<>'Cancelled' then
  for it in select value from jsonb_array_elements(old.items) loop
   update products set stock_qty=stock_qty+(it->>'qty')::int where id=(it->>'id')::bigint;
  end loop;
 end if;
 return new;
end$$;
drop trigger if exists t_restock on orders; create trigger t_restock after update on orders for each row execute function restock_cancel();

create or replace function guard_role() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if new.role is distinct from old.role and auth.uid() is not null and coalesce(current_setting('app.role_change',true),'')<>'1' then raise exception 'Role cannot be changed from the app'; end if;
 if new.id=auth.uid() and coalesce(new.blocked,false) then raise exception 'You cannot block yourself'; end if;
 return new;
end$$;
create or replace function set_role(p_user uuid,p_role text) returns void language plpgsql security definer set search_path=public as $$
begin
 if not is_admin() then raise exception 'Admins only'; end if;
 if p_role not in('admin','customer') then raise exception 'Bad role'; end if;
 if p_user=auth.uid() then raise exception 'You cannot change your own role'; end if;
 perform set_config('app.role_change','1',true);
 update profiles set role=p_role where id=p_user;
end$$;
revoke all on function set_role from public; grant execute on function set_role to authenticated;

create or replace function place_order(p_items jsonb,p_cust jsonb,p_coupon text default null) returns bigint
language plpgsql security definer set search_path=public as $$
declare pr profiles; it jsonb; p products; q int; u numeric; sub numeric:=0; ln jsonb:='[]'; city text:=p_cust->>'city';
 dfee numeric; disc numeric:=0; cc coupons; oid bigint; pay text:=coalesce(p_cust->>'payment','COD');
begin
 if auth.uid() is null then raise exception 'Login required'; end if;
 if jsonb_array_length(p_items) not between 1 and 60 then raise exception 'Bad cart'; end if;
 select * into pr from profiles where id=auth.uid();
 for it in select value from jsonb_array_elements(p_items) loop
  q:=(it->>'qty')::int; if q<1 or q>1000 then raise exception 'Bad quantity'; end if;
  select * into p from products where id=(it->>'id')::bigint for update;
  if not found then raise exception 'Product not found'; end if;
  if p.stock_qty<q then raise exception 'Out of stock: %',p.name_en; end if;
  u:=p.retail_price;
  if pr.type='wholesale' and pr.status='approved' and q>=p.wholesale_moq then
   u:=case when q>=p.wholesale_moq*2 then round(p.wholesale_price*(100-setting('tier2_pct'))/100) else p.wholesale_price end; end if;
  update products set stock_qty=stock_qty-q where id=p.id;
  sub:=sub+u*q; ln:=ln||jsonb_build_array(jsonb_build_object('id',p.id,'name',p.name_en,'qty',q,'price',u));
 end loop;
 if sub<setting('min_order') then raise exception 'Minimum order is Rs. %',setting('min_order'); end if;
 dfee:=case when sub>=setting('free_over') then 0 when city='DG Khan' then setting('delivery_dgkhan')
  when city in('Multan','Lahore','Bahawalpur','Faisalabad','Rawalpindi','Sialkot','Gujranwala') then setting('delivery_punjab') else setting('delivery_other') end;
 if p_coupon is not null and sub>=500 then
  select * into cc from coupons where code=upper(p_coupon) and active;
  if found then disc:=case cc.kind when 'flat' then cc.value else least(cc.max,round(sub*cc.value/100)) end;
  elsif exists(select 1 from profiles where ref_code=upper(p_coupon) and id<>auth.uid()) then disc:=100; end if;
 end if;
 if pay like 'Udhaar%' then pay:=case when pr.type='wholesale' and pr.status='approved' then 'Udhaar' else 'COD' end;
 elsif pay not in('COD','Easypaisa','JazzCash') then pay:='COD'; end if;
 insert into orders(user_id,name,phone,city,area,address,payment,items,subtotal,delivery,discount,coupon,total)
 values(auth.uid(),left(p_cust->>'name',80),left(p_cust->>'phone',20),city,left(p_cust->>'area',60),left(p_cust->>'address',300),
  pay,ln,sub,dfee,disc,upper(p_coupon),sub-disc+dfee) returning id into oid;
 return oid;
end$$;
revoke all on function place_order from public; grant execute on function place_order to authenticated;

update profiles set role='admin',status='approved' where lower(email)='amoeed021@gmail.com';
