-- Run AFTER schema.sql. Production hardening: OTP-verified admin, server-side pricing, stock, coupons, tracking.
alter table profiles add column if not exists role text default 'customer', add column if not exists ref_code text unique;
alter table orders add column if not exists discount numeric default 0, add column if not exists coupon text, add column if not exists tracking_no text;
alter table orders drop constraint if exists orders_status_check;
alter table orders add constraint orders_status_check check(status in('Pending','Packed','Shipped','Delivered'));
alter table products add constraint stock_nonneg check(stock_qty>=0);

-- Admin = profile with role 'admin' (role is set ONLY by trigger from the OTP-verified phone)
create or replace function is_admin() returns bool language sql stable security definer set search_path=public as
$$select exists(select 1 from profiles where id=auth.uid() and role='admin')$$;

create or replace function profiles_guard() returns trigger language plpgsql security definer set search_path=public as $$
declare ph text;
begin
 select phone into ph from auth.users where id=new.id;
 new.phone:=ph;
 new.role:=case when ph in('923158120199') then 'admin' else 'customer' end;   -- admin 0315-8120199
 new.ref_code:='DG'||upper(substr(replace(new.id::text,'-',''),1,5));
 new.status:=case when new.role='admin' or new.type<>'wholesale' then 'approved' else 'pending' end;
 return new;
end$$;
drop trigger if exists t_prof_guard on profiles;
create trigger t_prof_guard before insert on profiles for each row execute function profiles_guard();

create table if not exists coupons(code text primary key,kind text check(kind in('flat','pct')),value numeric,max numeric default 300,active bool default true);
insert into coupons values('DGKHAN50','flat',50,50,true),('RASHAN10','pct',10,300,true) on conflict do nothing;
alter table coupons enable row level security; create policy c_admin on coupons for all using(is_admin()) with check(is_admin());

-- Orders can ONLY be created through place_order (prices, stock, delivery, coupon computed on the server)
drop policy if exists o_ins on orders;
create or replace function place_order(p_items jsonb,p_cust jsonb,p_coupon text default null) returns bigint
language plpgsql security definer set search_path=public as $$
declare pr profiles; it jsonb; p products; q int; u numeric; sub numeric:=0; ln jsonb:='[]'; city text:=p_cust->>'city';
 dfee numeric; disc numeric:=0; cc coupons; oid bigint; pay text:=coalesce(p_cust->>'payment','COD');
begin
 if auth.uid() is null then raise exception 'Login required'; end if;
 if jsonb_array_length(p_items) not between 1 and 60 then raise exception 'Bad cart'; end if;
 select * into pr from profiles where id=auth.uid();
 for it in select value from jsonb_array_elements(p_items) loop
  q:=(it->>'qty')::int; if q<1 or q>1000 then raise exception 'Bad quantity'; end if;
  select * into p from products where id=(it->>'id')::bigint for update;
  if not found then raise exception 'Product not found'; end if;
  if p.stock_qty<q then raise exception 'Out of stock: %',p.name_en; end if;
  u:=p.retail_price;
  if pr.type='wholesale' and pr.status='approved' and q>=p.wholesale_moq then
   u:=case when q>=p.wholesale_moq*2 then round(p.wholesale_price*.97) else p.wholesale_price end; end if;
  update products set stock_qty=stock_qty-q where id=p.id;
  sub:=sub+u*q; ln:=ln||jsonb_build_array(jsonb_build_object('id',p.id,'name',p.name_en,'qty',q,'price',u));
 end loop;
 dfee:=case when sub>=3000 then 0 when city='DG Khan' then 99
  when city in('Multan','Lahore','Bahawalpur','Faisalabad','Rawalpindi','Sialkot','Gujranwala') then 199 else 250 end;
 if p_coupon is not null and sub>=500 then
  select * into cc from coupons where code=upper(p_coupon) and active;
  if found then disc:=case cc.kind when 'flat' then cc.value else least(cc.max,round(sub*cc.value/100)) end;
  elsif exists(select 1 from profiles where ref_code=upper(p_coupon) and id<>auth.uid()) then disc:=100; end if;
 end if;
 if pay like 'Udhaar%' then pay:=case when pr.type='wholesale' and pr.status='approved' then 'Udhaar' else 'COD' end;
 elsif pay not in('COD','Easypaisa','JazzCash') then pay:='COD'; end if;
 insert into orders(user_id,name,phone,city,area,address,payment,items,subtotal,delivery,discount,coupon,total)
 values(auth.uid(),left(p_cust->>'name',80),left(p_cust->>'phone',20),city,left(p_cust->>'area',60),left(p_cust->>'address',300),
  pay,ln,sub,dfee,disc,upper(p_coupon),sub-disc+dfee) returning id into oid;
 return oid;
end$$;
revoke all on function place_order from public; grant execute on function place_order to authenticated;

-- Storage: users upload only into their own folder; only admin uploads product photos
drop policy if exists st_ins on storage.objects;
create policy st_ins on storage.objects for insert to authenticated with check(
 (bucket_id='shop-cards' and (storage.foldername(name))[1]=auth.uid()::text) or (bucket_id='products' and is_admin()));
