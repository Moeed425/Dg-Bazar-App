-- 15 admin rights: roles, categories, riders, deals, banners, notices, reviews, returns, app text, backup.
create or replace function is_admin() returns bool language sql stable security definer set search_path=public as $$select exists(select 1 from profiles where id=auth.uid() and role in('admin','manager'))$$;
create or replace function is_super() returns bool language sql stable security definer set search_path=public as $$select exists(select 1 from profiles where id=auth.uid() and role='admin')$$;
drop policy if exists s_all on settings; create policy s_all on settings for all using(is_super()) with check(is_super());

create table if not exists categories(id bigint generated always as identity primary key,name text unique not null,name_ur text,icon text default '📦',hidden bool default false,sort int default 0);
insert into categories(name,name_ur,icon,sort) values('Atta','آٹا','🌾',1),('Cheeni','چینی','🍚',2),('Ghee/Oil','گھی/تیل','🛢️',3),('Daalain','دالیں','🫘',4),('Chawal','چاول','🍛',5),('Soap','صابن','🧼',6),('Masala','مصالحہ','🌶️',7),('Chai','چائے','🍵',8),('Dairy','ڈیری','🥛',9) on conflict do nothing;
create table if not exists riders(id bigint generated always as identity primary key,name text not null,phone text,bike_no text,status text default 'available',location text,updated_at timestamptz default now());
alter table orders add column if not exists rider_id bigint references riders(id);
create table if not exists deals(id bigint generated always as identity primary key,product_id bigint references products(id) on delete cascade,price numeric not null,starts_at timestamptz default now(),ends_at timestamptz not null,active bool default true);
create table if not exists banners(id bigint generated always as identity primary key,title text,image text not null,active bool default true);
create table if not exists notifications(id bigint generated always as identity primary key,title text,body text,created_at timestamptz default now());
create table if not exists reviews(id bigint generated always as identity primary key,product_id bigint references products(id) on delete cascade,user_id uuid references auth.users,stars int check(stars between 1 and 5),comment text,created_at timestamptz default now(),unique(product_id,user_id));
create table if not exists complaints(id bigint generated always as identity primary key,order_id bigint,user_id uuid references auth.users,kind text default 'complaint',message text,status text default 'open',created_at timestamptz default now());
create table if not exists app_text(key text primary key,value text);
do $$ declare t text; begin foreach t in array array['categories','riders','deals','banners','notifications','reviews','complaints','app_text'] loop execute format('alter table %I enable row level security',t); end loop; end$$;
do $$ declare t text; begin foreach t in array array['categories','deals','banners','notifications'] loop
 execute format('drop policy if exists %1$s_r on %1$I',t);
 execute format('create policy %1$s_r on %1$I for select using(true)',t);
 execute format('drop policy if exists %1$s_w on %1$I',t);
 execute format('create policy %1$s_w on %1$I for all using(is_admin()) with check(is_admin())',t);
end loop; end$$;
drop policy if exists rid_all on riders; create policy rid_all on riders for all using(is_admin()) with check(is_admin());
drop policy if exists at_r on app_text; create policy at_r on app_text for select using(true);
drop policy if exists at_w on app_text; create policy at_w on app_text for all using(is_super()) with check(is_super());
drop policy if exists rv_r on reviews; create policy rv_r on reviews for select using(true);
drop policy if exists rv_i on reviews; create policy rv_i on reviews for insert with check(user_id=auth.uid());
drop policy if exists rv_u on reviews; create policy rv_u on reviews for update using(user_id=auth.uid());
drop policy if exists rv_d on reviews; create policy rv_d on reviews for delete using(user_id=auth.uid() or is_admin());
drop policy if exists cm_i on complaints; create policy cm_i on complaints for insert with check(user_id=auth.uid());
drop policy if exists cm_s on complaints; create policy cm_s on complaints for select using(user_id=auth.uid() or is_admin());
drop policy if exists cm_u on complaints; create policy cm_u on complaints for update using(is_admin());

alter table orders drop constraint if exists orders_status_check;
alter table orders add constraint orders_status_check check(status in('Pending','Packed','Shipped','Delivered','Cancelled','Refunded'));
create or replace function restock_cancel() returns trigger language plpgsql security definer set search_path=public as $$
declare it jsonb;
begin
 if new.status in('Cancelled','Refunded') and old.status not in('Cancelled','Refunded') then
  for it in select value from jsonb_array_elements(old.items) loop
   update products set stock_qty=stock_qty+(it->>'qty')::int where id=(it->>'id')::bigint;
  end loop;
 end if;
 return new;
end$$;

create or replace function set_role(p_user uuid,p_role text) returns void language plpgsql security definer set search_path=public as $$
begin
 if not is_super() then raise exception 'Super admin only'; end if;
 if p_role not in('admin','manager','customer') then raise exception 'Bad role'; end if;
 if p_user=auth.uid() then raise exception 'You cannot change your own role'; end if;
 perform set_config('app.role_change','1',true);
 update profiles set role=p_role where id=p_user;
end$$;
create or replace function set_role_by_email(p_email text,p_role text) returns void language plpgsql security definer set search_path=public as $$
declare u uuid;
begin
 select id into u from profiles where lower(email)=lower(p_email);
 if u is null then raise exception 'No registered user with this email'; end if;
 perform set_role(u,p_role);
end$$;
create or replace function backup_all() returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_super() then raise exception 'Super admin only'; end if;
 return jsonb_build_object('at',now(),'products',(select coalesce(jsonb_agg(t),'[]') from products t),'orders',(select coalesce(jsonb_agg(t),'[]') from orders t),'profiles',(select coalesce(jsonb_agg(t),'[]') from profiles t),
  'coupons',(select coalesce(jsonb_agg(t),'[]') from coupons t),'categories',(select coalesce(jsonb_agg(t),'[]') from categories t),'riders',(select coalesce(jsonb_agg(t),'[]') from riders t),'deals',(select coalesce(jsonb_agg(t),'[]') from deals t),
  'banners',(select coalesce(jsonb_agg(t),'[]') from banners t),'reviews',(select coalesce(jsonb_agg(t),'[]') from reviews t),'complaints',(select coalesce(jsonb_agg(t),'[]') from complaints t),'settings',(select coalesce(jsonb_agg(t),'[]') from settings t),'app_text',(select coalesce(jsonb_agg(t),'[]') from app_text t));
end$$;
revoke all on function set_role,set_role_by_email,backup_all from public; grant execute on function set_role,set_role_by_email,backup_all to authenticated;

create or replace function place_order(p_items jsonb,p_cust jsonb,p_coupon text default null) returns bigint
language plpgsql security definer set search_path=public as $$
declare pr profiles; it jsonb; p products; q int; u numeric; sub numeric:=0; ln jsonb:='[]'; city text:=p_cust->>'city';
 dfee numeric; disc numeric:=0; cc coupons; oid bigint; pay text:=coalesce(p_cust->>'payment','COD');
begin
 if auth.uid() is null then raise exception 'Login required'; end if;
 if coalesce((select value from app_text where key='maintenance'),'')='on' and not is_admin() then raise exception 'Dukan band hai. Please try later.'; end if;
 if jsonb_array_length(p_items) not between 1 and 60 then raise exception 'Bad cart'; end if;
 select * into pr from profiles where id=auth.uid();
 for it in select value from jsonb_array_elements(p_items) loop
  q:=(it->>'qty')::int; if q<1 or q>1000 then raise exception 'Bad quantity'; end if;
  select * into p from products where id=(it->>'id')::bigint for update;
  if not found then raise exception 'Product not found'; end if;
  if p.stock_qty<q then raise exception 'Out of stock: %',p.name_en; end if;
  u:=p.retail_price;
  if pr.type='wholesale' and pr.status='approved' and q>=p.wholesale_moq then
   u:=case when q>=p.wholesale_moq*2 then round(p.wholesale_price*(100-setting('tier2_pct'))/100) else p.wholesale_price end; end if;
  update products set stock_qty=stock_qty-q where id=p.id;
  u:=least(u,coalesce((select min(price) from deals where product_id=p.id and active and now() between starts_at and ends_at),u));
  sub:=sub+u*q; ln:=ln||jsonb_build_array(jsonb_build_object('id',p.id,'name',p.name_en,'qty',q,'price',u));
 end loop;
 if sub<setting('min_order') then raise exception 'Minimum order is Rs. %',setting('min_order'); end if;
 dfee:=case when sub>=setting('free_over') then 0 when city='DG Khan' then setting('delivery_dgkhan')
  when city in('Multan','Lahore','Bahawalpur','Faisalabad','Rawalpindi','Sialkot','Gujranwala') then setting('delivery_punjab') else setting('delivery_other') end;
 if p_coupon is not null and sub>=500 then
  select * into cc from coupons where code=upper(p_coupon) and active;
  if found then disc:=case cc.kind when 'flat' then cc.value else least(cc.max,round(sub*cc.value/100)) end;
  elsif exists(select 1 from profiles where ref_code=upper(p_coupon) and id<>auth.uid()) then disc:=100; end if;
 end if;
 if pay like 'Udhaar%' then pay:=case when pr.type='wholesale' and pr.status='approved' then 'Udhaar' else 'COD' end;
 elsif pay not in('COD','Easypaisa','JazzCash') then pay:='COD'; end if;
 insert into orders(user_id,name,phone,city,area,address,payment,items,subtotal,delivery,discount,coupon,total)
 values(auth.uid(),left(p_cust->>'name',80),left(p_cust->>'phone',20),city,left(p_cust->>'area',60),left(p_cust->>'address',300),
  pay,ln,sub,dfee,disc,upper(p_coupon),sub-disc+dfee) returning id into oid;
 return oid;
end$$;
revoke all on function place_order from public; grant execute on function place_order to authenticated;
update profiles set role='admin' where lower(email)='amoeed021@gmail.com';
