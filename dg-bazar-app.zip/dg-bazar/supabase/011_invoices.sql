create sequence if not exists invoice_seq start 1001;
create table if not exists invoices(id bigint generated always as identity primary key,invoice_no text unique,customer_name text,customer_phone text,customer_address text,shop_name text,shop_address text,shop_phone text,owner_name text,note text,subtotal numeric default 0,discount numeric default 0,total numeric default 0,paid numeric default 0,balance numeric default 0,payment_method text default 'Cash',status text default 'paid' check(status in('paid','partial','unpaid','void')),created_at timestamptz default now(),created_by uuid default auth.uid());
create table if not exists invoice_items(id bigint generated always as identity primary key,invoice_id bigint references invoices(id) on delete cascade,product_id bigint references products(id),name text not null,qty numeric not null check(qty>0),unit text default 'pcs',price numeric not null check(price>=0),line_total numeric not null,stock_used numeric default 0);
create table if not exists invoice_payments(id bigint generated always as identity primary key,invoice_id bigint references invoices(id) on delete cascade,amount numeric not null,method text,created_at timestamptz default now(),by uuid default auth.uid());
alter table invoices enable row level security; alter table invoice_items enable row level security; alter table invoice_payments enable row level security;
drop policy if exists inv_all on invoices; create policy inv_all on invoices for all using(is_admin()) with check(is_admin());
drop policy if exists invi_all on invoice_items; create policy invi_all on invoice_items for all using(is_admin()) with check(is_admin());
drop policy if exists invp_all on invoice_payments; create policy invp_all on invoice_payments for all using(is_admin()) with check(is_admin());

create or replace function create_invoice(p jsonb) returns bigint language plpgsql security definer set search_path=public as $$
declare iid bigint; it jsonb; pr products; q numeric; pu numeric; un numeric; sub numeric:=0; tot numeric; st text; pid bigint;
 dis numeric:=greatest(coalesce(nullif(p->>'discount','')::numeric,0),0); pd numeric:=greatest(coalesce(nullif(p->>'paid','')::numeric,0),0);
begin
 if not is_admin() then raise exception 'Admins only'; end if;
 if jsonb_typeof(p->'items')<>'array' or jsonb_array_length(p->'items') not between 1 and 200 then raise exception 'Add at least one item'; end if;
 insert into invoices(invoice_no,customer_name,customer_phone,customer_address,shop_name,shop_address,shop_phone,owner_name,note,payment_method,discount)
 values('INV-'||lpad(nextval('invoice_seq')::text,6,'0'),left(coalesce(nullif(p->>'customer_name',''),'Walk-in customer'),100),left(p->>'customer_phone',30),left(p->>'customer_address',300),left(p->>'shop_name',120),left(p->>'shop_address',300),left(p->>'shop_phone',40),left(p->>'owner_name',100),left(p->>'note',500),coalesce(nullif(p->>'payment_method',''),'Cash'),dis) returning id into iid;
 for it in select value from jsonb_array_elements(p->'items') loop
  q:=(it->>'qty')::numeric; pu:=(it->>'price')::numeric; un:=coalesce(nullif(it->>'units','')::numeric,0); pid:=nullif(it->>'product_id','')::bigint;
  if q is null or q<=0 or pu is null or pu<0 then raise exception 'Bad quantity or price'; end if;
  if pid is not null then
   select * into pr from products where id=pid for update;
   if not found then raise exception 'Product not found'; end if;
   if pr.stock_qty<un then raise exception 'Out of stock: % (have %)',pr.name_en,pr.stock_qty; end if;
   update products set stock_qty=stock_qty-un where id=pid;
  end if;
  insert into invoice_items(invoice_id,product_id,name,qty,unit,price,line_total,stock_used)
  values(iid,pid,left(coalesce(nullif(it->>'name',''),'Item'),200),q,left(coalesce(it->>'unit','pcs'),30),pu,round(q*pu,2),case when pid is null then 0 else un end);
  sub:=sub+round(q*pu,2);
 end loop;
 if dis>sub then raise exception 'Discount is more than the bill'; end if;
 tot:=sub-dis; if pd>tot then raise exception 'Paid amount is more than the total'; end if;
 st:=case when pd>=tot then 'paid' when pd>0 then 'partial' else 'unpaid' end;
 update invoices set subtotal=sub,total=tot,paid=pd,balance=tot-pd,status=st where id=iid;
 if pd>0 then insert into invoice_payments(invoice_id,amount,method) values(iid,pd,coalesce(nullif(p->>'payment_method',''),'Cash')); end if;
 return iid;
end$$;

create or replace function void_invoice(p_id bigint) returns void language plpgsql security definer set search_path=public as $$
declare inv invoices; it record;
begin
 if not is_admin() then raise exception 'Admins only'; end if;
 select * into inv from invoices where id=p_id for update;
 if not found then raise exception 'Bill not found'; end if;
 if inv.status='void' then raise exception 'Bill is already void'; end if;
 for it in select * from invoice_items where invoice_id=p_id and product_id is not null and stock_used>0 loop
  update products set stock_qty=stock_qty+it.stock_used where id=it.product_id;
 end loop;
 update invoices set status='void' where id=p_id;
end$$;

create or replace function add_payment(p_id bigint,p_amount numeric,p_method text default 'Cash') returns void language plpgsql security definer set search_path=public as $$
declare inv invoices;
begin
 if not is_admin() then raise exception 'Admins only'; end if;
 select * into inv from invoices where id=p_id for update;
 if not found then raise exception 'Bill not found'; end if;
 if inv.status='void' then raise exception 'Bill is void'; end if;
 if p_amount<=0 or p_amount>inv.balance then raise exception 'Amount must be more than 0 and not more than the balance (%)',inv.balance; end if;
 update invoices set paid=paid+p_amount,balance=balance-p_amount,status=case when balance-p_amount<=0 then 'paid' else 'partial' end where id=p_id;
 insert into invoice_payments(invoice_id,amount,method) values(p_id,p_amount,coalesce(p_method,'Cash'));
end$$;
revoke all on function create_invoice from public; revoke all on function void_invoice from public; revoke all on function add_payment from public;
grant execute on function create_invoice to authenticated; grant execute on function void_invoice to authenticated; grant execute on function add_payment to authenticated;
notify pgrst, 'reload schema';
