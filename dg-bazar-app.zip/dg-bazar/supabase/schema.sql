-- DG Bazar schema. Run in Supabase SQL editor.
create table profiles(id uuid primary key references auth.users on delete cascade,phone text,type text default 'retail' check(type in('retail','wholesale')),
 shop_name text,shop_city text,shop_address text,card_url text,status text default 'approved' check(status in('pending','approved','rejected')),created_at timestamptz default now());
create table products(id bigint generated always as identity primary key,name_en text not null,name_ur text,image_url text,category text,
 retail_price numeric not null,wholesale_price numeric not null,wholesale_moq int default 12,unit text default 'piece',stock_qty int default 0,barcode text,is_featured bool default false);
create table orders(id bigint generated always as identity primary key,user_id uuid references auth.users,name text,phone text,city text,area text,address text,
 payment text default 'COD',items jsonb not null,subtotal numeric,delivery numeric,total numeric,status text default 'Pending' check(status in('Pending','Shipped','Delivered')),created_at timestamptz default now());
create index on orders(city,status);create index on products(category);

create function is_admin() returns bool language sql stable as $$select coalesce(auth.jwt()->>'email','')='admin@dg-bazar.pk'$$;
alter table profiles enable row level security;alter table products enable row level security;alter table orders enable row level security;
create policy p_sel on profiles for select using(id=auth.uid() or is_admin());
create policy p_ins on profiles for insert with check(id=auth.uid() and (type='retail' or status='pending'));
create policy p_upd on profiles for update using(is_admin());
create policy pr_sel on products for select using(true);
create policy pr_all on products for all using(is_admin()) with check(is_admin());
create policy o_ins on orders for insert with check(user_id is null or user_id=auth.uid());
create policy o_sel on orders for select using(user_id=auth.uid() or is_admin());
create policy o_upd on orders for update using(is_admin());
insert into storage.buckets(id,name,public) values('shop-cards','shop-cards',true),('products','products',true) on conflict do nothing;
create policy st_ins on storage.objects for insert with check(bucket_id in('shop-cards','products'));
create policy st_sel on storage.objects for select using(true);

-- 30 seed products (image_url empty: UI shows category emoji; add Unsplash/own URLs via admin)
insert into products(name_en,name_ur,category,retail_price,wholesale_price,wholesale_moq,unit,stock_qty,is_featured) values
('Dalda Banaspati Ghee 1kg','dalda ghee','Ghee/Oil',620,585,12,'piece',200,true),
('Sufi Cooking Oil 1L','sufi oil','Ghee/Oil',590,560,12,'piece',250,true),
('Dalda Cooking Oil 5L','dalda oil','Ghee/Oil',2950,2830,4,'piece',80,false),
('Eva Cooking Oil 1L','eva oil','Ghee/Oil',560,535,12,'piece',150,false),
('Guard Super Kernel Basmati 5kg','guard chawal','Chawal',1850,1740,6,'piece',90,true),
('Falak Sella Rice 5kg','falak chawal','Chawal',1650,1550,6,'piece',70,false),
('Kisan Rice 1kg','kisan chawal','Chawal',360,335,12,'kg',300,false),
('Fauji Atta 20kg','fauji atta','Atta',2900,2780,5,'piece',100,true),
('Chakki Fresh Atta 10kg','chakki atta','Atta',1480,1420,5,'piece',120,true),
('Maida 1kg','maida','Atta',190,175,12,'kg',150,false),
('Besan 1kg','besan','Atta',380,355,12,'kg',90,false),
('Cheeni (Sugar) 1kg','cheeni','Cheeni',185,172,20,'kg',500,true),
('Cheeni (Sugar) 50kg Bori','cheeni bori','Cheeni',8900,8550,1,'carton',40,false),
('Gur 1kg','gur','Cheeni',260,240,10,'kg',60,false),
('Daal Chana 1kg','daal chana','Daalain',340,315,12,'kg',200,false),
('Daal Masoor 1kg','daal masoor','Daalain',330,305,12,'kg',180,false),
('Daal Moong 1kg','daal moong','Daalain',380,355,12,'kg',150,false),
('Daal Mash 1kg','daal mash','Daalain',560,525,12,'kg',100,false),
('Kala Chana 1kg','kala chana','Daalain',310,290,12,'kg',130,false),
('Surf Excel 1kg','surf excel','Soap',620,585,12,'piece',200,true),
('Surf Excel 500g','surf excel','Soap',320,300,24,'piece',200,false),
('Lux Soap 3-pack','lux soap','Soap',270,250,24,'piece',300,false),
('Safeguard Soap 3-pack','safeguard','Soap',285,265,24,'piece',250,false),
('Lifebuoy Soap 3-pack','lifebuoy','Soap',255,235,24,'piece',250,false),
('Shan Biryani Masala','shan masala','Masala',130,118,24,'piece',400,true),
('National Karahi Masala','national masala','Masala',125,113,24,'piece',350,false),
('Shan Chaat Masala','shan chaat','Masala',95,85,24,'piece',300,false),
('Tapal Danedar Tea 430g','tapal chai','Chai',690,650,12,'piece',160,true),
('Lipton Yellow Label 430g','lipton chai','Chai',660,620,12,'piece',160,false),
('Nestle Milkpak 1L Carton (12)','milkpak','Dairy',2300,2200,1,'carton',60,false);
