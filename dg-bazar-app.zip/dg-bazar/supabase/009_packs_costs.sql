-- Bora/Carton pack rates, admin-only purchase rates, purchases.
alter table products alter column stock_qty type numeric;
alter table products add column if not exists bora_kg numeric, add column if not exists bora_rate numeric, add column if not exists carton_kg numeric, add column if not exists carton_rate numeric, add column if not exists pack_wholesale_only bool default true;
create table if not exists product_costs(product_id bigint primary key references products(id) on delete cascade,purchase_price numeric default 0);
create table if not exists purchases(id bigint generated always as identity primary key,product_id bigint references products(id),qty_kg numeric not null,rate_per_kg numeric not null,supplier text,note text,created_at timestamptz default now(),by uuid default auth.uid());
alter table product_costs enable row level security; alter table purchases enable row level security;
drop policy if exists costs_all on product_costs; create policy costs_all on product_costs for all using(is_super()) with check(is_super());
drop policy if exists purch_all on purchases; create policy purch_all on purchases for all using(is_super()) with check(is_super());

create or replace function add_purchase(p_product bigint,p_qty numeric,p_rate numeric,p_supplier text,p_note text) returns void language plpgsql security definer set search_path=public as $$
declare st numeric; oc numeric;
begin
 if not is_super() then raise exception 'Super admin only'; end if;
 if p_qty<=0 or p_rate<=0 then raise exception 'Bad quantity or rate'; end if;
 select stock_qty into st from products where id=p_product for update;
 select purchase_price into oc from product_costs where product_id=p_product;
 insert into purchases(product_id,qty_kg,rate_per_kg,supplier,note) values(p_product,p_qty,p_rate,left(p_supplier,80),left(p_note,200));
 update products set stock_qty=stock_qty+p_qty where id=p_product;
 insert into product_costs(product_id,purchase_price) values(p_product,case when coalesce(oc,0)>0 and coalesce(st,0)>0 then round((st*oc+p_qty*p_rate)/(st+p_qty),2) else p_rate end)
 on conflict(product_id) do update set purchase_price=excluded.purchase_price;
end$$;
revoke all on function add_purchase from public; grant execute on function add_purchase to authenticated;

create or replace function restock_cancel() returns trigger language plpgsql security definer set search_path=public as $$
declare it jsonb;
begin
 if new.status in('Cancelled','Refunded') and old.status not in('Cancelled','Refunded') then
  for it in select value from jsonb_array_elements(old.items) loop
   update products set stock_qty=stock_qty+coalesce((it->>'kg')::numeric,(it->>'qty')::numeric) where id=(it->>'id')::bigint;
  end loop;
 end if;
 return new;
end$$;

create or replace function place_order(p_items jsonb,p_cust jsonb,p_coupon text default null) returns bigint
language plpgsql security definer set search_path=public as $$
declare pr profiles; it jsonb; p products; q int; u numeric; sub numeric:=0; ln jsonb:='[]'; city text:=p_cust->>'city';
 dfee numeric; disc numeric:=0; cc coupons; oid bigint; pay text:=coalesce(p_cust->>'payment','COD'); pk text; kgs numeric; w numeric; rt numeric; nm text; wsok bool;
begin
 if auth.uid() is null then raise exception 'Login required'; end if;
 if coalesce((select value from app_text where key='maintenance'),'')='on' and not is_admin() then raise exception 'Dukan band hai. Please try later.'; end if;
 if jsonb_array_length(p_items) not between 1 and 60 then raise exception 'Bad cart'; end if;
 select * into pr from profiles where id=auth.uid();
 wsok:=(pr.type='wholesale' and pr.status='approved');
 for it in select value from jsonb_array_elements(p_items) loop
  q:=(it->>'qty')::int; pk:=coalesce(it->>'pack','kg'); if q<1 or q>1000 then raise exception 'Bad quantity'; end if;
  select * into p from products where id=(it->>'id')::bigint for update;
  if not found then raise exception 'Product not found'; end if;
  nm:=p.name_en;
  if pk in('bora','carton') then
   w:=case pk when 'bora' then p.bora_kg else p.carton_kg end; rt:=case pk when 'bora' then p.bora_rate else p.carton_rate end;
   if w is null or rt is null then raise exception '% rate not set for %',pk,p.name_en; end if;
   if coalesce(p.pack_wholesale_only,true) and not wsok then raise exception 'Bora/Carton rates are for approved dukan buyers only'; end if;
   u:=round(w*rt,2); kgs:=q*w; nm:=p.name_en||' ('||initcap(pk)||' '||w||'kg)';
  else
   pk:='kg'; kgs:=q; u:=p.retail_price;
   if wsok and q>=p.wholesale_moq then u:=case when q>=p.wholesale_moq*2 then round(p.wholesale_price*(100-setting('tier2_pct'))/100) else p.wholesale_price end; end if;
   u:=least(u,coalesce((select min(price) from deals where product_id=p.id and active and now() between starts_at and ends_at),u));
  end if;
  if p.stock_qty<kgs then raise exception 'Out of stock: %',p.name_en; end if;
  update products set stock_qty=stock_qty-kgs where id=p.id;
  sub:=sub+u*q; ln:=ln||jsonb_build_array(jsonb_build_object('id',p.id,'name',nm,'qty',q,'price',u,'pack',pk,'kg',kgs));
 end loop;
 if sub<setting('min_order') then raise exception 'Minimum order is Rs. %',setting('min_order'); end if;
 dfee:=case when sub>=setting('free_over') then 0 when city='DG Khan' then setting('delivery_dgkhan')
  when city in('Multan','Lahore','Bahawalpur','Faisalabad','Rawalpindi','Sialkot','Gujranwala') then setting('delivery_punjab') else setting('delivery_other') end;
 if p_coupon is not null and sub>=500 then
  select * into cc from coupons where code=upper(p_coupon) and active;
  if found then disc:=case cc.kind when 'flat' then cc.value else least(cc.max,round(sub*cc.value/100)) end;
  elsif exists(select 1 from profiles where ref_code=upper(p_coupon) and id<>auth.uid()) then disc:=100; end if;
 end if;
 if pay like 'Udhaar%' then pay:=case when wsok then 'Udhaar' else 'COD' end;
 elsif pay not in('COD','Easypaisa','JazzCash') then pay:='COD'; end if;
 insert into orders(user_id,name,phone,city,area,address,payment,items,subtotal,delivery,discount,coupon,total)
 values(auth.uid(),left(p_cust->>'name',80),left(p_cust->>'phone',20),city,left(p_cust->>'area',60),left(p_cust->>'address',300),
  pay,ln,sub,dfee,disc,upper(p_coupon),sub-disc+dfee) returning id into oid;
 return oid;
end$$;
revoke all on function place_order from public; grant execute on function place_order to authenticated;
