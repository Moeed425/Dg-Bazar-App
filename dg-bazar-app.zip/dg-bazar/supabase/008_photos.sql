alter table profiles add column if not exists avatar_url text;
insert into storage.buckets(id,name,public) values('avatars','avatars',true) on conflict do nothing;
drop policy if exists av_ins on storage.objects;
create policy av_ins on storage.objects for insert to authenticated with check(bucket_id='avatars' and (storage.foldername(name))[1]=auth.uid()::text);
create or replace function set_avatar(p_url text) returns void language plpgsql security definer set search_path=public as $$
begin
 if auth.uid() is null then raise exception 'Login required'; end if;
 update profiles set avatar_url=left(p_url,500) where id=auth.uid();
end$$;
revoke all on function set_avatar from public; grant execute on function set_avatar to authenticated;
