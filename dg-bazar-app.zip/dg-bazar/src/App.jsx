import{useRef,useState,useEffect,useMemo,createContext,useContext}from'react';
import{createClient}from'@supabase/supabase-js';
const sb=createClient(import.meta.env.VITE_SUPABASE_URL,import.meta.env.VITE_SUPABASE_ANON_KEY);
let WA=import.meta.env.VITE_WHATSAPP||'923000000000';const TXT={};const RATE={};
const isOpen=()=>{if(TXT.maintenance==='on')return false;if(TXT.auto_hours!=='on')return true;const p=Object.fromEntries(new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Karachi',hour:'2-digit',minute:'2-digit',hour12:false,weekday:'short'}).formatToParts(new Date()).map(x=>[x.type,x.value]));const dow=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(p.weekday);if((TXT.closed_days||'').split(',').includes(String(dow)))return false;const m=(+p.hour%24)*60+ +p.minute,tm=h=>{const[a,b]=(h||'').split(':');return +a*60+ +b},o=tm(TXT.open_time||'09:00'),c=tm(TXT.close_time||'22:00');return o<=c?m>=o&&m<c:m>=o||m<c};
const CITIES=['DG Khan','Multan','Lahore','Karachi','Islamabad','Bahawalpur','Faisalabad','Rawalpindi','Peshawar','Quetta','Sialkot','Gujranwala'];
const PUNJAB=['Multan','Lahore','Bahawalpur','Faisalabad','Rawalpindi','Sialkot','Gujranwala'];
const AREAS=['Sadar Bazaar','Kot Chutta','Taunsa Road','College Road','Block 1-10','Other'];
const CATS={Atta:['🌾','آٹا'],Cheeni:['🍚','چینی'],'Ghee/Oil':['🛢️','گھی/تیل'],Daalain:['🫘','دالیں'],Chawal:['🍛','چاول'],Soap:['🧼','صابن'],Masala:['🌶️','مصالحہ'],Chai:['🍵','چائے'],Dairy:['🥛','ڈیری']};
const T={ur:{search:'تلاش کریں',add:'کارٹ میں ڈالیں',login:'لاگ ان',banner:'ڈی جی خان سے پورے پاکستان تک - سستا کریانہ گھر تک',cart:'کارٹ',dukan:'دکان ریٹ',pcs:'عدد پر',total:'کل',place:'آرڈر کریں',all:'سب'},
 en:{search:'Search products',add:'Add to Cart',login:'Login',banner:'DG Khan Se Pooray Pakistan Tak - Sasta Karyana Ghar Tak',cart:'Cart',dukan:'Dukan Price',pcs:'pcs',total:'Total',place:'Place Order',all:'All'}};
const Ctx=createContext();const useA=()=>useContext(Ctx);
const errText=e=>[e.status,e.code,e.name,e.message].filter(Boolean).join(' | ')||JSON.stringify(e);
const norm=p=>'+92'+p.replace(/\D/g,'').replace(/^(92|0)/,'');const ST=['Pending','Packed','Shipped','Delivered'];const STX=[...ST,'Cancelled'];
const rs=n=>'Rs. '+Math.round(n).toLocaleString();
const SETV={delivery_dgkhan:99,delivery_punjab:199,delivery_other:250};const delivery=c=>c==='DG Khan'?SETV.delivery_dgkhan:PUNJAB.includes(c)?SETV.delivery_punjab:SETV.delivery_other;
const Btn=({c='',...p})=><button {...p} className={`rounded-lg px-3 py-2 font-semibold text-sm active:scale-95 transition ${c}`}/>;
const In=({value,onChange,...p})=>{const[v,setV]=useState(value??'');useEffect(()=>{if(value!==undefined)setV(value)},[value]);const c="w-full border rounded-lg p-2 text-sm";
 if(value===undefined)return<input dir="auto" autoComplete="off" autoCorrect="off" spellCheck={false} {...p} onChange={onChange} className={c}/>;
 return<input dir="auto" autoComplete="off" autoCorrect="off" spellCheck={false} {...p} value={v} onChange={e=>{setV(e.target.value);onChange&&onChange(e)}} className={c}/>};
const G='bg-green-600 text-white hover:bg-green-700';

export default function App(){
 const[lang,setLang]=useState(localStorage.lang||'en');const[city,setCity]=useState(localStorage.city);
 const[user,setUser]=useState(null);const[profile,setProfile]=useState(null);const[cart,setCart]=useState({});
 const[products,setProducts]=useState([]);const[maint,setMaint]=useState('');const[menu,setMenu]=useState(false);const[pid,setPid]=useState(null);const[modal,setModal]=useState(null);const[page,setPage]=useState('home');
 const t=T[lang];
 const loadP=async u=>{if(!u)return setProfile(null);const{data}=await sb.from('profiles').select('*').eq('id',u.id).maybeSingle();setProfile(data);if(!data&&!u.email)setModal('signup')};
 window.refreshProfile=()=>sb.auth.getSession().then(({data})=>loadP(data.session?.user));
 useEffect(()=>{sb.auth.getSession().then(({data})=>{setUser(data.session?.user??null);loadP(data.session?.user)});
  const{data:l}=sb.auth.onAuthStateChange((_,s)=>{setUser(s?.user??null);loadP(s?.user)});return()=>l.subscription.unsubscribe()},[]);
 useEffect(()=>{sb.from('reviews').select('product_id,stars').then(({data})=>{(data||[]).forEach(x=>{const q=RATE[x.product_id]||(RATE[x.product_id]={s:0,n:0});q.s+=x.stars;q.n++});setProducts(p=>[...p])});Promise.all([sb.from('products').select('*').order('id'),sb.from('categories').select('*').order('sort'),sb.from('deals').select('*').eq('active',true),sb.from('app_text').select('*')]).then(([pr,ca,de,tx])=>{const cs=ca.data||[],hid=new Set(cs.filter(c=>c.hidden).map(c=>c.name));
  if(cs.length){Object.keys(CATS).forEach(k=>delete CATS[k]);cs.filter(c=>!c.hidden).forEach(c=>CATS[c.name]=[c.icon||'📦',c.name_ur||c.name])}
  const now=Date.now(),dl={};(de.data||[]).forEach(d=>{if(new Date(d.starts_at)<=now&&new Date(d.ends_at)>now)dl[d.product_id]=d});
  (tx.data||[]).forEach(x=>{TXT[x.key]=x.value;if(x.key==='whatsapp'&&x.value)WA=x.value});
  setProducts((pr.data||[]).filter(p=>p.stock_qty>0&&!hid.has(p.category)).map(p=>dl[p.id]?{...p,retail_price:Math.min(p.retail_price,dl[p.id].price),wholesale_price:Math.min(p.wholesale_price,dl[p.id].price),old_price:p.retail_price,deal_end:dl[p.id].ends_at}:p));
  setMaint(TXT.maintenance==='on'?(TXT.maintenance_msg||'Dukan band hai'):'')});sb.from('settings').select('*').then(({data})=>{(data||[]).forEach(x=>SETV[x.key]=Number(x.value));setProducts(p=>[...p])})},[]);
 const isWS=profile?.type==='wholesale'&&profile?.status==='approved';
 const price=(p,q)=>isWS&&q>=p.wholesale_moq?p.wholesale_price:p.retail_price;
 const lines=useMemo(()=>Object.entries(cart).map(([id,q])=>{const p=products.find(x=>x.id==id);return p&&{p,q,unit:price(p,q),ws:isWS&&q>=p.wholesale_moq}}).filter(Boolean),[cart,products,isWS]);
 const subtotal=lines.reduce((s,l)=>s+l.unit*l.q,0),saved=lines.reduce((s,l)=>s+(l.ws?(l.p.retail_price-l.unit)*l.q:0),0);
 const setQ=(id,q)=>setCart(c=>{const n={...c};q<=0?delete n[id]:n[id]=q;return n});
 const ctx={pid,openP:id=>{setPid(id);setPage('product');scrollTo(0,0)},lang,t,city,user,profile,modal,isWS,cart,setQ,lines,subtotal,saved,setModal,setPage,price};
 if((location.pathname+location.hash).includes('admin'))return<Ctx.Provider value={ctx}><Admin/></Ctx.Provider>;
 if(maint&&!['admin','manager'].includes(profile?.role))return<div className="min-h-screen grid place-items-center text-center p-6"><div><div className="text-6xl">🛠️</div><h1 className="text-2xl font-extrabold text-green-700 mt-2">{maint}</h1><p className="text-sm text-gray-500 mt-2">DG Bazar</p></div></div>;
 return<Ctx.Provider value={ctx}><div dir={lang==='ur'?'rtl':'ltr'} className={`min-h-screen bg-gray-50 ${lang==='ur'?'ur':''}`}>
  {!city&&<CityModal onPick={c=>{localStorage.city=c;setCity(c)}}/>}
  <header className="bg-green-600 text-white sticky top-0 z-20 flex items-center gap-3 px-3 h-14 shadow">
   <button className="text-2xl" onClick={()=>setMenu(true)}>☰</button>
   <b className="flex-1 text-xl cursor-pointer" onClick={()=>setPage('home')}>{TXT.logo?<img src={TXT.logo} className="h-8"/>:'DG Bazar'}</b>
   <button className="text-xl" onClick={()=>{setPage('home');setTimeout(()=>document.getElementById('q')?.focus(),50)}}>🔍</button>
   <button className="text-xl" onClick={()=>setModal('notif')}>🔔</button>
   <button className="text-sm font-bold" onClick={()=>window.fontStep(-1)}>A−</button><button className="text-base font-bold" onClick={()=>window.fontStep(1)}>A+</button><button className="text-xl" onClick={()=>window.toggleTheme()}>🌓</button>
   <button className="relative text-xl" onClick={()=>setPage('cart')}>🛒{lines.length>0&&<b className="absolute -top-2 -right-2 bg-red-500 text-[10px] rounded-full px-1.5">{lines.length}</b>}</button>
  </header>
  {menu&&<div className="fixed inset-0 z-40 bg-black/50" onClick={()=>setMenu(false)}><div className="w-72 max-w-[80%] h-full bg-white p-4 space-y-2 overflow-auto" onClick={e=>e.stopPropagation()}>
   <div className="flex items-center gap-2"><Avatar url={profile?.avatar_url} name={profile?.full_name||user?.email||'G'} size={44}/><div><b className="text-green-600 text-xl">DG Bazar</b><p className="text-xs text-gray-500">{user?(profile?.full_name||user.email):'Guest'}</p></div></div>
   <Btn c="border w-full" onClick={()=>{localStorage.removeItem('city');setCity(null);setMenu(false)}}>📍 {city} (change)</Btn>
   <Btn c="border w-full" onClick={()=>{const l=lang==='ur'?'en':'ur';localStorage.lang=l;setLang(l)}}>🌐 {lang==='ur'?'English':'اردو'}</Btn>
   <Btn c="border w-full" onClick={()=>window.toggleTheme()}>🌓 Light / Dark</Btn>
   {user&&<Btn c="border w-full" onClick={()=>{setPage('myo');setMenu(false)}}>📦 My Orders</Btn>}
   {['admin','manager'].includes(profile?.role)&&<a className="block text-center border rounded-lg py-2 font-semibold text-sm" href="#admin" onClick={()=>setTimeout(()=>location.reload(),50)}>⚙️ Admin panel</a>}
   {user?<Btn c="border w-full text-red-600" onClick={()=>{sb.auth.signOut();setMenu(false)}}>Logout</Btn>:<><Btn c={G+' w-full'} onClick={()=>{setModal('login');setMenu(false)}}>Login</Btn><Btn c="border w-full" onClick={()=>{setPage('register');setMenu(false)}}>Register</Btn></>}
   <Btn c="border w-full" onClick={()=>{setPage('about');setMenu(false)}}>ℹ️ About / Contact</Btn><a className="block text-xs underline" href="privacy.html">Privacy policy</a></div></div>}
  {modal==='login'&&<Login/>}{modal==='signup'&&<Signup/>}{modal==='notif'&&<Notif/>}
  {page==='home'?<Home products={products}/>:page==='product'?<ProductPage products={products}/>:page==='about'?<About/>:page==='profile'?<Profile/>:page==='cart'?<Cart/>:page==='myo'?<MyOrders/>:page==='register'?<Register/>:<Checkout/>}
  <footer className="bg-green-700 text-white text-sm p-6 pb-28"><b>{TXT.shop_name||'DG Bazar'}</b><br/>📍 {TXT.shop_address||'Sadar Bazaar'}{TXT.shop_city?', '+TXT.shop_city:', Dera Ghazi Khan'}<br/>{TXT.owner_name&&<span className="inline-flex items-center gap-2">{TXT.owner_photo&&<img src={TXT.owner_photo} className="w-8 h-8 rounded-full object-cover"/>}👤 Owner: {TXT.owner_name}</span>}<br/>📞 {TXT.owner_phone||TXT.shop_phone||'+'+WA}<br/>Delivering All Pakistan via TCS / Leopards<button onClick={()=>setPage('about')} className="underline block mt-2">About / Contact</button></footer>
  <BottomNav page={page} setPage={setPage} n={lines.length} user={user} setModal={setModal}/>
 </div></Ctx.Provider>}

const SearchCtx=createContext();let setSearchG=()=>{};
function Search(){const{t}=useA();return<input className="w-full border rounded-full px-4 py-2 text-sm" placeholder={t.search} onChange={e=>setSearchG(e.target.value)}/>}
function CityModal({onPick}){return<div className="fixed inset-0 bg-black/60 z-50 grid place-items-center p-4"><div className="bg-white rounded-2xl p-5 max-w-md w-full">
 <h2 className="font-extrabold text-green-600 text-lg mb-3">Apna Shehar Chunein / Select City</h2>
 <div className="grid grid-cols-2 gap-2">{CITIES.map(c=><Btn key={c} c="border hover:bg-green-50" onClick={()=>onPick(c)}>{c}</Btn>)}</div></div></div>}

function Home({products}){const{t,city,lang}=useA();const[cat,setCat]=useState('');const[q,setQ]=useState('');
 const list=products.filter(p=>(!cat||p.category===cat)&&(p.name_en+p.name_ur+p.category).toLowerCase().includes(q.toLowerCase()));
 return<main className="max-w-6xl mx-auto px-4 pt-3 space-y-4">
  <div className="relative"><span className="absolute left-4 top-3.5">🔍</span><input id="q" defaultValue={q} onChange={e=>setQ(e.target.value)} placeholder={lang==='ur'?t.search:'Daal search karo...'} className="w-full border rounded-2xl pl-11 pr-4 py-3 bg-white"/></div>
  <Slider/>
  <h2 className="text-center text-2xl font-extrabold text-green-600">Dera Ghazi Khan Ka Apna Bazar</h2>
  <div className="text-center"><span className="inline-block bg-green-100 text-green-700 text-xs font-bold rounded-full px-3 py-1">{city==='DG Khan'?'⚡ 2-Hour Delivery':'🚚 2-3 Days via TCS/Leopards'} · {rs(delivery(city))}</span></div>
  <h3 className="text-xl font-extrabold">Categories</h3>
  <div className="flex gap-3 overflow-x-auto pb-1">{[['',['🏪',t.all]],...Object.entries(CATS)].map(([k,[e,u]])=><button key={k} onClick={()=>setCat(k)} className={`shrink-0 w-28 rounded-2xl border p-3 text-center ${cat===k?'border-green-600 bg-green-50':'bg-white'}`}><div className="w-14 h-14 mx-auto rounded-full bg-green-100 grid place-items-center text-3xl">{e}</div><div className="mt-2 text-sm font-semibold">{lang==='ur'?u:(k||t.all)}</div></button>)}</div>
  <FlashBar products={products}/>
  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">{list.map(p=><Card key={p.id} p={p}/>)}</div>{!list.length&&<p className="text-center text-gray-500">No products found.</p>}</main>}
function FlashBar({products}){const d=products.filter(p=>p.deal_end);const[,n]=useState(0);useEffect(()=>{const i=setInterval(()=>n(x=>x+1),1000);return()=>clearInterval(i)},[]);if(!d.length)return null;
 const ms=Math.max(0,Math.min(...d.map(p=>+new Date(p.deal_end)))-Date.now()),z=x=>String(Math.floor(x)).padStart(2,'0'),pct=Math.round(Math.max(...d.map(p=>(1-p.retail_price/p.old_price)*100)));
 return<div className="rounded-2xl p-4 text-white flex items-center justify-between bg-gradient-to-r from-red-500 to-orange-500"><div className="font-extrabold">⚡ Flash Sale - Save up to {pct}%</div><div className="font-bold">⏱ {z(ms/36e5)}:{z(ms/6e4%60)}:{z(ms/1e3%60)}</div></div>}
function Card({p}){const{t,lang,cart,setQ,isWS,openP}=useA();const q=cart[p.id]||0,r=RATE[p.id];
 return<div className="bg-white rounded-2xl border overflow-hidden flex flex-col shadow-sm">
  <div className="relative aspect-square bg-green-50 grid place-items-center overflow-hidden cursor-pointer" onClick={()=>openP(p.id)}>{p.image_url?<img src={p.image_url} alt={p.name_en} loading="lazy" className="object-cover w-full h-full"/>:<span className="text-6xl">{CATS[p.category]?.[0]||'📦'}</span>}{p.deal_end&&<span className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold rounded-full px-3 py-1">SALE</span>}</div>
  <div className="p-3 flex flex-col flex-1"><div className="font-bold leading-tight cursor-pointer" onClick={()=>openP(p.id)}>{p.name_en}</div><div className="ur text-sm text-gray-500">{p.name_ur}</div><div className="text-sm text-gray-500">1 {p.unit}</div>
   {r&&<div className="text-sm">⭐ {(r.s/r.n).toFixed(1)}</div>}
   <div className="mt-1"><b className="text-green-600 text-lg">Rs {Math.round(p.retail_price)}</b>{p.old_price&&<s className="text-gray-400 text-sm ml-2">Rs {Math.round(p.old_price)}</s>}</div>
   <span className="text-[11px] bg-green-100 text-green-700 rounded px-1.5 py-0.5 w-fit">{t.dukan}: Rs {Math.round(p.wholesale_price)} {lang==='ur'?'':'on'} {p.wholesale_moq} {t.pcs}</span>
   {isWS&&q>=p.wholesale_moq&&<span className="text-[11px] text-green-700 font-bold">✅ Wholesale Price Applied!</span>}
   <div className="mt-auto pt-2">{q?<div className="flex items-center justify-between"><Btn c="border" onClick={()=>setQ(p.id,q-1)}>−</Btn><b>{q}</b><Btn c={G} onClick={()=>setQ(p.id,Math.min(q+1,p.stock_qty))}>+</Btn></div>:<Btn c={G+' w-full py-3 rounded-xl'} onClick={()=>setQ(p.id,1)}>+ {lang==='ur'?'ڈالیں':'Add'}</Btn>}</div></div></div>}
function ProductPage({products}){const{pid,setPage,setQ,cart,isWS,t}=useA();const p=products.find(x=>x.id==pid);const[n,setN]=useState(1);const[rv,setRv]=useState([]);
 useEffect(()=>{if(p)sb.from('reviews').select('*').eq('product_id',p.id).order('id',{ascending:false}).then(({data})=>setRv(data||[]))},[pid]);
 if(!p)return<main className="p-6">Product not found.<Btn c="border ml-2" onClick={()=>setPage('home')}>Back</Btn></main>;
 const r=RATE[p.id],tot=(cart[p.id]||0)+n,add=go=>{setQ(p.id,Math.min(tot,p.stock_qty));go&&setPage('checkout')};
 return<main className="max-w-xl mx-auto px-4 pt-3 space-y-3">
  <button onClick={()=>setPage('home')} className="text-green-600 font-semibold">← Back</button>
  <div className="aspect-[4/3] rounded-3xl bg-green-50 grid place-items-center overflow-hidden">{p.image_url?<img src={p.image_url} className="object-cover w-full h-full"/>:<span className="text-8xl">{CATS[p.category]?.[0]||'📦'}</span>}</div>
  <h1 className="text-2xl font-extrabold">{p.name_en}</h1><div className="ur text-lg text-gray-500">{p.name_ur}</div><div className="text-gray-500">1 {p.unit}</div>
  {r&&<div>⭐ <b>{(r.s/r.n).toFixed(1)}</b> ({r.n})</div>}
  <div className="border rounded-2xl p-4"><div>Retail: <b className="text-green-600 text-2xl">Rs {Math.round(p.retail_price)}</b>{p.old_price&&<s className="text-gray-400 ml-2">Rs {Math.round(p.old_price)}</s>}</div>
   <div className="text-sm text-green-700 mt-1">{t.dukan}: Rs {Math.round(p.wholesale_price)} on {p.wholesale_moq}+ {t.pcs}</div>{isWS&&tot>=p.wholesale_moq&&<div className="text-sm font-bold text-green-700">✅ Wholesale Price Applied!</div>}</div>
  <div className={p.stock_qty<10?'text-red-600 font-bold':'text-green-600 font-bold'}>In Stock ({p.stock_qty} left)</div>
  <div className="inline-flex items-center border rounded-2xl"><Btn onClick={()=>setN(Math.max(1,n-1))}>−</Btn><b className="px-5">{n}</b><Btn onClick={()=>setN(Math.min(p.stock_qty,n+1))}>+</Btn></div>
  <div className="grid grid-cols-2 gap-3"><Btn c="border py-3 rounded-2xl" onClick={()=>add(false)}>🛒 Add to Cart</Btn><Btn c={G+' py-3 rounded-2xl'} onClick={()=>add(true)}>Buy Now</Btn></div>
  <a target="_blank" href={`https://wa.me/${WA}?text=${encodeURIComponent('Order: '+p.name_en+' x'+n+' ('+Math.round(p.retail_price)+')')}`} className="block text-center bg-amber-100 text-amber-900 font-bold rounded-2xl py-3">📞 Order via WhatsApp</a>
  <hr/><h3 className="text-xl font-extrabold">💬 Reviews ({rv.length})</h3>{!rv.length&&<p className="text-gray-500">No reviews yet. Be the first to review!</p>}
  {rv.map(x=><div key={x.id} className="text-sm border-b py-1">{'⭐'.repeat(x.stars)} {x.comment}</div>)}<Btn c="border" onClick={async()=>{await review(p.id);location.reload()}}>⭐ Write a review</Btn></main>}
const BottomNav=({page,setPage,n,user,setModal})=><nav className="fixed bottom-0 inset-x-0 z-30 bg-white border-t flex justify-around items-end px-2 pt-2 pb-3">{[['home','🏠','Home'],['search','🔍','Search'],['cart','🛒','Cart'],['myo','📦','Orders'],['profile','👤','Profile']].map(([k,e,l])=>k==='cart'?<button key={k} onClick={()=>setPage('cart')} className="relative -mt-8 flex flex-col items-center text-xs font-semibold text-green-700"><span className="w-14 h-14 rounded-full bg-green-600 text-white text-2xl grid place-items-center shadow-lg">{e}</span>{n>0&&<b className="absolute top-0 right-0 bg-red-500 text-white text-[10px] rounded-full px-1.5">{n}</b>}{l}</button>:<button key={k} onClick={()=>{if(k==='search'){setPage('home');setTimeout(()=>document.getElementById('q')?.focus(),50)}else if(k==='myo'&&!user)setModal('login');else setPage(k)}} className={`flex flex-col items-center text-xs font-semibold ${page===k?'text-green-600':'text-gray-500'}`}><span className="text-xl">{e}</span>{l}</button>)}</nav>;
function Profile(){const{user,profile,setModal,setPage}=useA();return<main className="max-w-md mx-auto p-4 space-y-3"><h2 className="text-xl font-extrabold">Profile</h2>
 {user?<><div className="bg-white border rounded-2xl p-4 text-sm space-y-1"><div className="flex items-center gap-3"><label className="relative cursor-pointer"><Avatar url={profile?.avatar_url} name={profile?.full_name||user.email} size={72}/><span className="absolute -bottom-1 -right-1 bg-green-600 text-white rounded-full w-6 h-6 grid place-items-center text-xs">📷</span><input type="file" accept="image/*" className="hidden" onChange={e=>{const f=e.target.files[0];e.target.value='';f&&setAvatar(user.id,f)}}/></label><b className="text-lg">{profile?.full_name||'My account'}</b></div><div>{user.email||profile?.email}</div><div>📱 {profile?.phone}</div><div>Role: {profile?.role==='admin'?'Super admin':profile?.role==='manager'?'Manager':profile?.type==='wholesale'?'Wholesale (Dukan) '+(profile.status):'Retail (Ghar)'}</div></div>
  <Btn c="border w-full" onClick={()=>setPage('myo')}>📦 My Orders</Btn>{['admin','manager'].includes(profile?.role)&&<a className="block text-center border rounded-lg py-2 font-semibold text-sm" href="#admin" onClick={()=>setTimeout(()=>location.reload(),50)}>⚙️ Admin panel</a>}<Btn c="border w-full text-red-600" onClick={()=>sb.auth.signOut()}>Logout</Btn></>
 :<><p className="text-gray-500">Login to see your orders and get dukan prices.</p><Btn c={G+' w-full'} onClick={()=>setModal('login')}>Login</Btn><Btn c="border w-full" onClick={()=>setPage('register')}>Create account</Btn></>}<a href="privacy.html" className="block text-sm underline">Privacy policy</a></main>}
function Notif(){const{setModal}=useA();const[l,setL]=useState([]);useEffect(()=>{sb.from('notifications').select('*').order('id',{ascending:false}).limit(10).then(({data})=>setL(data||[]))},[]);
 return<Sheet title="🔔 Offers & notices" close={()=>setModal(null)}>{!l.length&&<p className="text-sm">No new notices.</p>}{l.map(x=><div key={x.id} className="text-sm border-b py-1"><b>{x.title}</b> {x.body}<div className="text-xs text-gray-500">{new Date(x.created_at).toLocaleDateString()}</div></div>)}</Sheet>}

function Cart(){const{lines,subtotal,saved,setQ,setPage,city,t}=useA();
 return<main className="max-w-2xl mx-auto p-3 space-y-2"><h2 className="font-extrabold text-lg">{t.cart}</h2>
  {!lines.length&&<p>Cart is empty.</p>}
  {lines.map(({p,q,unit,ws})=><div key={p.id} className="bg-white rounded-xl p-3 flex items-center gap-3"><div className="flex-1"><div className="font-semibold text-sm">{p.name_en}</div>
   <div className="text-xs">{rs(unit)} × {q} {ws&&<span className="text-green-700 font-bold">Wholesale Price Applied!</span>}</div></div>
   <Btn c="border" onClick={()=>setQ(p.id,q-1)}>−</Btn><b>{q}</b><Btn c={G} onClick={()=>setQ(p.id,q+1)}>+</Btn></div>)}
  {saved>0&&<div className="bg-green-100 text-green-800 rounded-xl p-3 font-bold">🎉 You save {rs(saved)}</div>}
  <div className="bg-white rounded-xl p-3 text-sm">Subtotal {rs(subtotal)}<br/>Delivery ({city}) {rs(delivery(city))}<br/><b className="text-lg">{t.total}: {rs(subtotal+delivery(city))}</b></div>
  {lines.length>0&&<Btn c={G+' w-full'} onClick={()=>setPage('checkout')}>Checkout</Btn>}</main>}

function Checkout(){const{lines,subtotal,city,user,setPage,setModal,t}=useA();const[f,setF]=useState({name:'',phone:'',area:'',address:'',payment:'COD'});const[busy,setBusy]=useState(false);const[done,setDone]=useState(null);
 const u=k=>e=>setF({...f,[k]:e.target.value});
 const place=async()=>{if(!isOpen())return alert((TXT.maintenance_msg||'Dukan abhi band hai')+'\nOpening hours: '+(TXT.open_time||'09:00')+' to '+(TXT.close_time||'22:00'));if(!user)return setModal('login');if(!f.name||!f.phone||!f.address)return alert('Please fill all fields');setBusy(true);
  const{data,error}=await sb.rpc('place_order',{p_items:lines.map(l=>({id:l.p.id,qty:l.q})),p_cust:{...f,city},p_coupon:f.coupon||null});
  setBusy(false);error?alert(error.message):setDone(data)};
 if(done)return<main className="p-6 text-center"><h2 className="text-2xl font-extrabold text-green-600">Order #{done} placed ✅</h2><Btn c={G+' mt-4'} onClick={()=>location.reload()}>Continue Shopping</Btn></main>;
 return<main className="max-w-md mx-auto p-3 space-y-2"><h2 className="font-extrabold text-lg">Checkout</h2>
  <In placeholder="Full Name" value={f.name} onChange={u('name')}/><In placeholder="Phone (03XX...)" value={f.phone} onChange={u('phone')}/><In value={city} disabled/>
  {city==='DG Khan'&&<select className="w-full border rounded-lg p-2 text-sm" value={f.area} onChange={u('area')}><option value="">Select Area</option>{AREAS.map(a=><option key={a}>{a}</option>)}</select>}
  <textarea className="w-full border rounded-lg p-2 text-sm" placeholder="Full Address" value={f.address} onChange={u('address')}/>
  {['COD','Easypaisa','JazzCash'].map(m=><label key={m} className="flex gap-2 bg-white rounded-lg p-2 text-sm"><input type="radio" checked={f.payment===m} onChange={()=>setF({...f,payment:m})}/>{m}{m==='COD'&&' (Cash on Delivery)'}</label>)}
  <In placeholder="Coupon: DGKHAN50 / RASHAN10 / friend's invite code" value={f.coupon||''} onChange={u('coupon')}/><Btn c={G+' w-full'} disabled={busy} onClick={place}>{t.place} · {rs(subtotal+delivery(city))}</Btn></main>}

function Login(){const{setModal,setPage}=useA();const[mode,setMode]=useState('phone');const[id,setId]=useState('');const[otp,setOtp]=useState('');const[sent,setSent]=useState(false);const[busy,setBusy]=useState(false);
 const tgt=()=>mode==='phone'?{phone:norm(id)}:{email:id.trim().toLowerCase()};
 const send=async()=>{setBusy(true);const{error}=await sb.auth.signInWithOtp({...tgt(),...(mode==='email'?{options:{shouldCreateUser:false}}:{})});setBusy(false);
  error?alert(mode==='email'&&/signup/i.test(error.message)?'No account with this email. Please Register first.':error.message):setSent(true)};
 const verify=async()=>{setBusy(true);const{error}=await sb.auth.verifyOtp({...tgt(),token:otp.trim(),type:mode==='phone'?'sms':'email'});setBusy(false);error?alert(error.message):setModal(null)};
 return<Sheet title="Login" close={()=>setModal(null)}>
  <div className="flex gap-2">{[['phone','📱 Phone'],['email','✉️ Email']].map(([k,l])=><Btn key={k} c={mode===k?G+' flex-1':'border flex-1'} onClick={()=>{setMode(k);setSent(false);setId('')}}>{l}</Btn>)}</div>
  {!sent?<><In placeholder={mode==='phone'?'03XX XXXXXXX':'you@email.com'} type={mode==='email'?'email':'tel'} value={id} onChange={e=>setId(e.target.value)}/><Btn c={G+' w-full'} disabled={busy} onClick={send}>Send OTP</Btn></>
  :<><p className="text-xs text-gray-500">Code sent to {id}</p><In placeholder="6-digit OTP" inputMode="numeric" maxLength={8} value={otp} onChange={e=>setOtp(e.target.value)}/><Btn c={G+' w-full'} disabled={busy} onClick={verify}>Verify & Login</Btn></>}
  <p className="text-xs text-center">New here? <button className="text-green-700 underline" onClick={()=>{setModal(null);setPage('register')}}>Create account</button></p></Sheet>}
const Sheet=({title,close,children})=><div className="fixed inset-0 bg-black/50 z-40 grid place-items-center p-4"><div className="bg-white rounded-2xl p-5 w-full max-w-sm space-y-2 max-h-[90vh] overflow-auto"><div className="flex justify-between"><b>{title}</b>{close&&<button onClick={close}>✕</button>}</div>{children}</div></div>;

function Signup(){const{user,setModal,city}=useA();const[type,setType]=useState('retail');const[s,setS]=useState({shop_name:'',shop_city:city||'',shop_address:''});const[file,setFile]=useState(null);const[busy,setBusy]=useState(false);
 const save=async()=>{setBusy(true);let card_url=null;
  if(type==='wholesale'){if(!file||!s.shop_name)return setBusy(false)||alert('Shop name and visiting card required');
   const path=`${user.id}/${Date.now()}`;const up=await sb.storage.from('shop-cards').upload(path,file);if(up.error){setBusy(false);return alert(up.error.message)}
   card_url=sb.storage.from('shop-cards').getPublicUrl(path).data.publicUrl}
  const{error}=await sb.from('profiles').insert({id:user.id,phone:user.phone,type,...(type==='wholesale'?{...s,card_url,status:'pending'}:{status:'approved'})});
  setBusy(false);error?alert(error.message):(setModal(null),location.reload())};
 return<Sheet title="Aap kaun hain?">{[['retail','Ghar ke liye (Retail Customer)'],['wholesale','Dukan ke liye (Wholesale Shopkeeper)']].map(([k,l])=>
  <label key={k} className={`flex gap-2 border rounded-lg p-2 text-sm ${type===k?'border-green-600 bg-green-50':''}`}><input type="radio" checked={type===k} onChange={()=>setType(k)}/>{l}</label>)}
  {type==='wholesale'&&<><In placeholder="Shop Name" onChange={e=>setS({...s,shop_name:e.target.value})}/><In placeholder="City" value={s.shop_city} onChange={e=>setS({...s,shop_city:e.target.value})}/>
   <In placeholder="Shop Address" onChange={e=>setS({...s,shop_address:e.target.value})}/><label className="text-xs">Shop Visiting Card (image)<input type="file" accept="image/*" onChange={e=>setFile(e.target.files[0])}/></label>
   <p className="text-xs text-amber-600">Status: pending until admin approves.</p></>}
  <Btn c={G+' w-full'} disabled={busy} onClick={save}>Continue</Btn></Sheet>}

/* ---------- ADMIN (/admin) ---------- */
function Admin(){const{user,profile,modal,setModal}=useA();const[tab,setTab]=useState('dash');const[e,setE]=useState('admin@dg-bazar.pk');const[pw,setPw]=useState('');
 if(!['admin','manager'].includes(profile?.role))return<div className="min-h-screen grid place-items-center p-4 text-center"><div className="bg-white shadow rounded-xl p-5 space-y-2"><b>Admin Login</b><p className="text-sm">Login with the admin mobile number (OTP).</p>{user?<p className="text-red-600 text-sm">This account is not an admin.</p>:<Btn c={G} onClick={()=>setModal('login')}>Login with OTP</Btn>}{modal==='login'&&<Login/>}</div></div>;
 return<div className="max-w-5xl mx-auto p-3"><div className="flex gap-2 mb-3 flex-wrap">{[['dash','Dashboard'],['prod','Products'],['ord','Orders'],['ver','Shopkeepers'],['cus','Customers'],['cou','Coupons'],['log','Activity'],['cat','Categories'],['rid','Riders'],['dea','Deals'],['ban','Banners'],['not','Notify'],['rev','Reviews'],['com','Returns'],['sta','Analytics'],['set','Settings']].filter(t=>profile?.role==='admin'||!['set'].includes(t[0])).map(([k,l])=><Btn key={k} c={tab===k?G:'bg-white border'} onClick={()=>setTab(k)}>{l}</Btn>)}<Btn c="border ml-auto" onClick={()=>window.fontStep(-1)}>A−</Btn><Btn c="border" onClick={()=>window.fontStep(1)}>A+</Btn><Btn c="border" onClick={()=>window.toggleTheme()}>🌓</Btn><a href="#" onClick={()=>setTimeout(()=>location.reload(),50)} className="text-sm underline self-center">Store</a></div>
  {tab==='dash'?<Dash/>:tab==='prod'?<Prods/>:tab==='ord'?<Orders/>:tab==='cus'?<Customers/>:tab==='cou'?<Coupons/>:tab==='log'?<Activity/>:tab==='set'?<Settings/>:tab==='cat'?<Cats/>:tab==='rid'?<Riders/>:tab==='dea'?<Deals/>:tab==='ban'?<Banners/>:tab==='not'?<Notify/>:tab==='rev'?<Reviews/>:tab==='com'?<Complaints/>:tab==='sta'?<Stats/>:<Verify/>}</div>}
function Dash(){const[s,setS]=useState({});useEffect(()=>{(async()=>{const d=new Date();d.setHours(0,0,0,0);const c=q=>q.then(x=>x.count??0);
 const[o,t,p,u,l,pe,cm]=await Promise.all([c(sb.from('orders').select('id',{count:'exact',head:true})),sb.from('orders').select('total').gte('created_at',d.toISOString()).not('status','in','(Cancelled,Refunded)'),c(sb.from('orders').select('id',{count:'exact',head:true}).eq('status','Pending')),c(sb.from('profiles').select('id',{count:'exact',head:true})),c(sb.from('products').select('id',{count:'exact',head:true}).lt('stock_qty',5)),c(sb.from('profiles').select('id',{count:'exact',head:true}).eq('status','pending').eq('type','wholesale')),c(sb.from('complaints').select('id',{count:'exact',head:true}).eq('status','open'))]);
 setS({o,today:(t.data||[]).reduce((a,x)=>a+Number(x.total),0),p,u,l,pe,cm})})()},[]);
 const K=[['Total Orders',s.o],['Today Sale',s.today==null?null:rs(s.today)],['Pending Orders',s.p],['Customers',s.u],['Low Stock (<5)',s.l],['Shopkeepers to approve',s.pe],['Open Complaints',s.cm]];
 return<div className="grid grid-cols-2 gap-3">{K.map(([l,v])=><div key={l} className="bg-white rounded-xl p-4"><div className="text-xs text-gray-500">{l}</div><div className="text-2xl font-extrabold text-green-600">{v??'...'}</div></div>)}<p className="col-span-2 text-xs text-gray-500">Numbers grow when customers place orders.</p></div>}

function Prods(){const[list,setList]=useState([]);const[ed,setEd]=useState(null);const load=()=>sb.from('products').select('*').order('id').then(({data})=>setList(data||[]));useEffect(()=>{load()},[]);
 const save=async()=>{const{id,...r}=ed;['retail_price','wholesale_price','wholesale_moq','stock_qty'].forEach(k=>r[k]=Number(r[k]||0));
  const{data,error}=await(id?sb.from('products').update(r).eq('id',id):sb.from('products').insert(r)).select();error?alert(error.message):!data?.length?alert('NOT saved: your account is not admin in the database'):(setEd(null),load())};
 const photo=async(id,f)=>{try{const b=await shrinkImg(f);const path=`p-${id}-${Date.now()}.jpg`;const{error}=await sb.storage.from('products').upload(path,b,{contentType:'image/jpeg'});if(error)return alert(error.message);await run(sb.from('products').update({image_url:sb.storage.from('products').getPublicUrl(path).data.publicUrl}).eq('id',id),load)}catch(e){alert('Photo failed: '+e.message)}};
 const quick=async(id,k,v,old)=>{if(String(v)===String(old))return;const{data,error}=await sb.from('products').update({[k]:Number(v)}).eq('id',id).select();error?alert(error.message):!data?.length?alert('NOT saved: your account is not admin in the database'):load()};
 const upload=async f=>{let b;try{b=await shrinkImg(f)}catch(e){return alert('Photo failed: '+e.message)}const p=`p-${Date.now()}.jpg`;const{error}=await sb.storage.from('products').upload(p,b,{contentType:'image/jpeg'});error?alert(error.message):setEd({...ed,image_url:sb.storage.from('products').getPublicUrl(p).data.publicUrl})};
 const F=[['name_en','Name (EN)'],['name_ur','Name (UR)'],['category','Category'],['retail_price','Retail Price'],['wholesale_price','Wholesale Price'],['wholesale_moq','MOQ'],['unit','Unit'],['stock_qty','Stock'],['barcode','Barcode']];
 return<div><Btn c={G+' mb-2'} onClick={()=>setEd({unit:'piece',wholesale_moq:12})}>+ Add Product</Btn>
  {ed&&<Sheet key={ed.id||'new'} title="Product" close={()=>setEd(null)}>{F.map(([k,l])=><label key={k} className="block text-xs text-gray-600">{l}<U o={ed} k={k} placeholder={l}/></label>)}
   <input type="file" accept="image/*" onChange={e=>e.target.files[0]&&upload(e.target.files[0])}/><label className="text-sm flex gap-2"><input type="checkbox" checked={!!ed.is_featured} onChange={e=>setEd({...ed,is_featured:e.target.checked})}/>Featured</label><Btn c={G+' w-full'} onClick={save}>Save</Btn></Sheet>}
  <div className="bg-white rounded-xl overflow-x-auto"><table className="w-full text-sm"><thead><tr className="text-xs text-gray-500"><th>Product</th><th>Retail</th><th>Dukan</th><th>MOQ</th><th>Stock</th><th></th></tr></thead><tbody>{list.map(p=><tr key={p.id} className="border-b"><td className="p-2"><label className="cursor-pointer block">{p.image_url?<img src={p.image_url} className="w-14 h-14 object-cover rounded"/>:<span className="text-3xl">📷</span>}<span className="block text-xs text-green-700 underline">Photo</span><input type="file" accept="image/*" className="hidden" onChange={e=>{const f=e.target.files[0];e.target.value='';f&&photo(p.id,f)}}/></label>{p.name_en}</td>{['retail_price','wholesale_price','wholesale_moq','stock_qty'].map(k=><td key={k}><input type="number" defaultValue={p[k]} className={`w-20 border rounded p-1 ${k==='stock_qty'&&p.stock_qty<30?'text-red-600 font-bold':''}`} onBlur={e=>quick(p.id,k,e.target.value,p[k])}/></td>)}
   <td><Btn onClick={()=>setEd(p)}>Edit</Btn><Btn c="text-red-600" onClick={async()=>{confirm('Delete?')&&(await sb.from('products').delete().eq('id',p.id),load())}}>Del</Btn></td></tr>)}</tbody></table></div></div>}
function Orders(){const[riders,setRiders]=useState([]);useEffect(()=>{sb.from('riders').select('*').then(({data})=>setRiders(data||[]))},[]);const[list,setList]=useState([]);const[fc,setFc]=useState('');const[fs,setFs]=useState('');
 const load=()=>{let q=sb.from('orders').select('*').order('id',{ascending:false}).limit(200);if(fc)q=q.eq('city',fc);if(fs)q=q.eq('status',fs);q.then(({data})=>setList(data||[]))};useEffect(load,[fc,fs]);
 return<div><div className="flex gap-2 mb-2"><select className="border rounded p-1 text-sm" onChange={e=>setFc(e.target.value)}><option value="">All Cities</option>{CITIES.map(c=><option key={c}>{c}</option>)}</select>
  <select className="border rounded p-1 text-sm" onChange={e=>setFs(e.target.value)}><option value="">All Status</option>{STX.map(c=><option key={c}>{c}</option>)}</select></div>
  <div className="bg-white rounded-xl overflow-x-auto"><table className="w-full text-sm"><tbody>{list.map(o=><tr key={o.id} className="border-b"><td className="p-2">#{o.id}</td><td>{o.name}<br/><span className="text-xs text-gray-500">{o.phone}</span></td><td>{o.city}</td><td>{rs(o.total)}</td><td>{o.payment}</td>
   <td><select className="border rounded p-1" value={o.rider_id||''} onChange={e=>sb.from('orders').update({rider_id:e.target.value||null}).eq('id',o.id).then(()=>load())}><option value="">Rider</option>{riders.map(x=><option key={x.id} value={x.id}>{x.name}</option>)}</select></td><td><input className="border rounded p-1 w-28" placeholder="TCS/Leopards #" defaultValue={o.tracking_no||''} onBlur={async e=>{await sb.from('orders').update({tracking_no:e.target.value}).eq('id',o.id)}}/></td><td><select value={o.status} className="border rounded p-1" onChange={async e=>{await sb.from('orders').update({status:e.target.value}).eq('id',o.id);load()}}>{STX.map(c=><option key={c}>{c}</option>)}</select></td></tr>)}</tbody></table></div></div>}
function Verify(){const[list,setList]=useState([]);const load=()=>sb.from('profiles').select('*').eq('status','pending').eq('type','wholesale').then(({data})=>setList(data||[]));useEffect(()=>{load()},[]);
 const set=async(id,status)=>{await sb.from('profiles').update({status}).eq('id',id);load()};
 return<div className="grid md:grid-cols-2 gap-3">{!list.length&&<p>No pending shopkeepers.</p>}{list.map(p=><div key={p.id} className="bg-white rounded-xl p-3 space-y-1"><b>{p.shop_name}</b><div className="text-xs">{p.shop_city} · {p.shop_address} · {p.phone}</div>
  <a href={p.card_url} target="_blank"><img src={p.card_url} className="h-32 rounded object-cover"/></a><div className="flex gap-2"><Btn c={G} onClick={()=>set(p.id,'approved')}>Approve</Btn><Btn c="bg-red-600 text-white" onClick={()=>set(p.id,'rejected')}>Reject</Btn></div></div>)}</div>}

function MyOrders(){const{user}=useA();const[l,setL]=useState([]);
 useEffect(()=>{sb.from('orders').select('*').eq('user_id',user.id).order('id',{ascending:false}).limit(20).then(({data})=>setL(data||[]))},[]);
 return<main className="max-w-lg mx-auto p-3 space-y-2"><h2 className="font-extrabold text-lg">📦 My Orders</h2>{!l.length&&<p>No orders yet.</p>}
  {l.map(o=><div key={o.id} className="bg-white rounded-xl p-3 text-sm"><b>#{o.id}</b> · {rs(o.total)} · {o.status}{o.tracking_no&&<> · Courier # {o.tracking_no}</>}
   <div className="text-xs text-gray-500">{o.items.map(i=>i.name+' ×'+i.qty).join(', ')}</div>
   <div className="flex gap-1 flex-wrap mt-1"><Btn c="border" onClick={()=>complain(o,'complaint')}>Complaint</Btn><Btn c="border" onClick={()=>complain(o,'return')}>Return</Btn>{o.items.map(i=><Btn key={i.id} c="border" onClick={()=>review(i.id)}>⭐ {i.name}</Btn>)}</div><div className="flex gap-1 mt-2">{ST.map((x,i)=><span key={x} className={`flex-1 text-center text-[11px] rounded p-1 ${i<=ST.indexOf(o.status)?'bg-green-600 text-white':'bg-gray-200'}`}>{x}</span>)}</div></div>)}</main>}

const L=({t,children})=><label className="block text-xs font-semibold text-gray-600">{t}{children}</label>;
function Register(){const{setPage,city}=useA();const[st,setSt]=useState(1);const[agree,setAgree]=useState(false);const[otp,setOtp]=useState('');const[busy,setBusy]=useState(false);const[left,setLeft]=useState(0);const[file,setFile]=useState(null);
 const[f,setF]=useState({name:'',email:'',phone:'',city:city||'',address:'',type:'retail',shop_name:'',shop_city:city||'',shop_address:''});
 const u=k=>e=>setF({...f,[k]:e.target.value});const W=f.type==='wholesale',em=f.email.trim().toLowerCase();
 useEffect(()=>{if(left<=0)return;const i=setTimeout(()=>setLeft(left-1),1000);return()=>clearTimeout(i)},[left]);
 const send=async()=>{
  if(f.name.trim().length<3)return alert('Enter your full name');
  if(!/^\S+@\S+\.\S+$/.test(em))return alert('Enter a valid email address');
  if(!/^03\d{9}$/.test(f.phone.replace(/\D/g,'')))return alert('Enter mobile like 03XXXXXXXXX');
  if(!f.city||f.address.trim().length<8)return alert('Enter your city and full address');
  if(W&&(!f.shop_name.trim()||!f.shop_address.trim()||!file))return alert('Shop name, shop address and visiting card are required');
  if(!agree)return alert('Please accept the terms');
  setBusy(true);const{error}=await sb.auth.signInWithOtp({email:em,options:{shouldCreateUser:true,data:{name:f.name}}});setBusy(false);
  error?alert(errText(error)):(setSt(2),setLeft(60))};
 const resend=async()=>{const{error}=await sb.auth.signInWithOtp({email:em});error?alert(errText(error)):setLeft(60)};
 const verify=async()=>{setBusy(true);const{data,error}=await sb.auth.verifyOtp({email:em,token:otp.trim(),type:'email'});
  if(error){setBusy(false);return alert(errText(error))}
  const uid=data.user.id;let card_url=null;
  if(W){const path=`${uid}/${Date.now()}`;const up=await sb.storage.from('shop-cards').upload(path,file);if(up.error){setBusy(false);return alert(up.error.message)}card_url=sb.storage.from('shop-cards').getPublicUrl(path).data.publicUrl}
  const row={id:uid,full_name:f.name.trim(),email:em,phone:f.phone.replace(/\D/g,''),city:f.city,address:f.address.trim(),type:f.type,status:W?'pending':'approved',...(W?{shop_name:f.shop_name.trim(),shop_city:f.shop_city,shop_address:f.shop_address.trim(),card_url}:{})};
  const{error:e2}=await sb.from('profiles').insert(row);setBusy(false);
  e2?alert(e2.code==='23505'?'This email/account is already registered. Please login.':e2.message):setSt(3)};
 return<main className="max-w-lg mx-auto p-3"><div className="bg-white rounded-2xl shadow p-5 space-y-3">
  <div className="flex items-center gap-2 text-xs font-bold">{['Details','Verify Email','Done'].map((x,i)=><span key={x} className={`flex-1 text-center rounded-full py-1 ${st>i?'bg-green-600 text-white':'bg-gray-200'}`}>{i+1}. {x}</span>)}</div>
  {st===1&&<>
   <h2 className="font-extrabold text-xl text-green-700">Create your DG Bazar account</h2>
   <L t="Full Name"><In value={f.name} onChange={u('name')} placeholder="e.g. Muhammad Ali"/></L>
   <L t="Email (OTP will be sent here)"><In type="email" value={f.email} onChange={u('email')} placeholder="you@email.com"/></L>
   <L t="Mobile Number"><In inputMode="tel" value={f.phone} onChange={u('phone')} placeholder="03XX XXXXXXX"/></L>
   <div className="grid grid-cols-2 gap-2"><L t="City"><select className="w-full border rounded-lg p-2 text-sm" value={f.city} onChange={u('city')}><option value="">Select</option>{CITIES.map(c=><option key={c}>{c}</option>)}</select></L></div>
   <L t="Full Address"><textarea className="w-full border rounded-lg p-2 text-sm" rows={2} value={f.address} onChange={u('address')} placeholder="House / street / area"/></L>
   <div className="space-y-1">{[['retail','Ghar ke liye (Retail Customer)'],['wholesale','Dukan ke liye (Wholesale Shopkeeper)']].map(([k,l])=><label key={k} className={`flex gap-2 border rounded-lg p-2 text-sm ${f.type===k?'border-green-600 bg-green-50':''}`}><input type="radio" checked={f.type===k} onChange={()=>setF({...f,type:k})}/>{l}</label>)}</div>
   {W&&<div className="border rounded-xl p-3 space-y-2 bg-green-50"><b className="text-sm">Shop details</b>
    <L t="Shop Name"><In value={f.shop_name} onChange={u('shop_name')}/></L>
    <L t="Shop City"><select className="w-full border rounded-lg p-2 text-sm" value={f.shop_city} onChange={u('shop_city')}>{CITIES.map(c=><option key={c}>{c}</option>)}</select></L>
    <L t="Shop Address"><In value={f.shop_address} onChange={u('shop_address')}/></L>
    <L t="Shop Visiting Card (photo)"><input type="file" accept="image/*" onChange={e=>setFile(e.target.files[0])}/></L>
    <p className="text-xs text-amber-700">Wholesale prices unlock after admin approves your shop.</p></div>}
   <label className="flex gap-2 text-xs"><input type="checkbox" checked={agree} onChange={e=>setAgree(e.target.checked)}/>I agree to DG Bazar terms and confirm the details are correct.</label>
   <Btn c={G+' w-full'} disabled={busy} onClick={send}>{busy?'Sending...':'Send OTP to my Email'}</Btn>
   <p className="text-xs text-center">Already registered? <button className="text-green-700 underline" onClick={()=>setPage('home')}>Go back & Login</button></p></>}
  {st===2&&<><h2 className="font-extrabold text-xl text-green-700">Check your email ✉️</h2>
   <p className="text-sm">We sent a 6-digit code to <b>{em}</b>. Check Spam/Promotions too.</p>
   <In placeholder="Enter OTP" inputMode="numeric" maxLength={8} value={otp} onChange={e=>setOtp(e.target.value)} className="text-center tracking-widest"/>
   <Btn c={G+' w-full'} disabled={busy||otp.length<6} onClick={verify}>{busy?'Verifying...':'Verify & Create Account'}</Btn>
   <div className="flex justify-between text-xs"><button className="underline" onClick={()=>setSt(1)}>Change email</button><button disabled={left>0} className="underline disabled:text-gray-400" onClick={resend}>{left>0?`Resend in ${left}s`:'Resend OTP'}</button></div></>}
  {st===3&&<div className="text-center space-y-3 py-4"><div className="text-5xl">🎉</div><h2 className="font-extrabold text-xl text-green-700">Account created!</h2>
   <p className="text-sm">{W?'Your shop is under review. Admin will approve it soon — until then you shop at retail prices.':'Welcome to DG Bazar. Happy shopping!'}</p>
   <Btn c={G} onClick={()=>{location.hash='';location.reload()}}>Start Shopping</Btn></div>}
 </div></main>}

function Install(){const[,f]=useState(0);useEffect(()=>{const h=()=>f(x=>x+1);addEventListener('ipready',h);return()=>removeEventListener('ipready',h)},[]);
 if(matchMedia('(display-mode: standalone)').matches||navigator.standalone)return null;
 const ios=/iphone|ipad|ipod/i.test(navigator.userAgent);
 return<Btn c={G} onClick={async()=>{if(window.__ip){window.__ip.prompt();await window.__ip.userChoice;window.__ip=null;f(x=>x+1)}else alert(ios?'iPhone: tap Share, then "Add to Home Screen".':'Browser menu (⋮) → "Install app" / "Add to Home screen".')}}>⬇ Install App</Btn>}

function Customers(){const[h,setH]=useState(null);const[l,setL]=useState([]);const[q,setQ]=useState('');
 const load=()=>sb.from('profiles').select('*').order('created_at',{ascending:false}).limit(200).then(({data})=>setL(data||[]));useEffect(()=>{load()},[]);
 const upd=async(id,p)=>{const{error}=await sb.from('profiles').update(p).eq('id',id);error?alert(error.message):load()};
 const f=l.filter(p=>[p.full_name,p.email,p.phone,p.shop_name].join(' ').toLowerCase().includes(q.toLowerCase()));
 return<div>{h&&<Sheet title={'Orders: '+(h.p.full_name||h.p.email)} close={()=>setH(null)}>{h.data.map(o=><div key={o.id} className="text-xs border-b py-1">#{o.id} · {rs(o.total)} · {o.status}<br/>{o.items.map(i=>i.name+' ×'+i.qty).join(', ')}</div>)}{!h.data.length&&'No orders'}</Sheet>}<In placeholder="Search name / email / phone" value={q} onChange={e=>setQ(e.target.value)}/>
  <div className="bg-white rounded-xl overflow-x-auto mt-2"><table className="w-full text-sm"><tbody>{f.map(p=><tr key={p.id} className="border-b"><td className="p-2"><b>{p.full_name||'-'}</b>{p.role==='admin'&&' 👑'}<br/><span className="text-xs text-gray-500">{p.email} · {p.phone}</span></td>
   <td className="text-xs">{p.type}<br/>{p.shop_name}</td><td className="text-xs">{p.status}{p.blocked&&' 🚫'}</td>
   <td>{p.type==='wholesale'&&p.status!=='approved'&&<Btn c={G} onClick={()=>upd(p.id,{status:'approved'})}>Approve</Btn>}{p.role!=='admin'&&<><Btn c="text-red-600" onClick={()=>upd(p.id,{blocked:!p.blocked})}>{p.blocked?'Unblock':'Block'}</Btn><Btn onClick={()=>upd(p.id,{type:p.type==='retail'?'wholesale':'retail',status:'approved'})}>→{p.type==='retail'?'Dukan':'Ghar'}</Btn><Btn onClick={async()=>{const{data}=await sb.from('orders').select('*').eq('user_id',p.id).order('id',{ascending:false});setH({p,data:data||[]})}}>📋</Btn><Btn onClick={async()=>{if(confirm('Make this user an admin?')){const{error}=await sb.rpc('set_role',{p_user:p.id,p_role:'admin'});error?alert(error.message):load()}}}>👑</Btn></>}</td></tr>)}</tbody></table></div></div>}
function Coupons(){const[l,setL]=useState([]);const[c,setC]=useState({code:'',kind:'flat',value:''});
 const load=()=>sb.from('coupons').select('*').then(({data})=>setL(data||[]));useEffect(()=>{load()},[]);
 const add=async()=>{const{error}=await sb.from('coupons').insert({code:c.code.trim().toUpperCase(),kind:c.kind,value:+c.value,max:300,active:true});error?alert(error.message):(setC({code:'',kind:'flat',value:''}),load())};
 return<div className="space-y-2"><div className="bg-white rounded-xl p-3 space-y-1"><In placeholder="CODE e.g. EID100" value={c.code} onChange={e=>setC({...c,code:e.target.value})}/>
  <div className="flex gap-2"><select className="border rounded-lg p-2 text-sm" value={c.kind} onChange={e=>setC({...c,kind:e.target.value})}><option value="flat">Rs. off</option><option value="pct">% off</option></select><In type="number" placeholder="Value" value={c.value} onChange={e=>setC({...c,value:e.target.value})}/></div><Btn c={G} onClick={add}>Add coupon</Btn></div>
  {l.map(x=><div key={x.code} className="bg-white rounded-xl p-3 flex items-center text-sm"><b className="flex-1">{x.code} · {x.kind==='flat'?'Rs. '+x.value:x.value+'%'}</b><Btn c={x.active?'border':G} onClick={async()=>{await sb.from('coupons').update({active:!x.active}).eq('code',x.code);load()}}>{x.active?'Disable':'Enable'}</Btn></div>)}</div>}
function Activity(){const[l,setL]=useState([]);useEffect(()=>{sb.from('admin_log').select('*').order('id',{ascending:false}).limit(50).then(({data})=>setL(data||[]))},[]);
 return<div className="bg-white rounded-xl p-3 text-xs space-y-1">{!l.length&&'No activity yet'}{l.map(x=><div key={x.id}>{new Date(x.at).toLocaleString()} · <b>{x.action}</b> · {x.detail}</div>)}</div>}

function Settings(){const[l,setL]=useState([]);const[m,setM]=useState('');const T={delivery_dgkhan:'Delivery: DG Khan (Rs.)',delivery_punjab:'Delivery: Punjab cities (Rs.)',delivery_other:'Delivery: rest of Pakistan (Rs.)',free_over:'Free delivery above (Rs.)',tier2_pct:'Extra wholesale discount at 2x MOQ (%)',min_order:'Minimum order (Rs., 0 = none)'};
 const load=()=>sb.from('settings').select('*').then(({data})=>setL(data||[]));useEffect(()=>{load()},[]);
 const save=async(k,v)=>{const{data,error}=await sb.from('settings').update({value:Number(v)}).eq('key',k).select();error?alert(error.message):!data?.length?alert('NOT saved: not an admin in the database'):(SETV[k]=Number(v),setM('Saved '+(T[k]||k)))};
 return<div className="space-y-2">{m&&<div className="text-green-700 text-sm font-bold">✓ {m}</div>}{l.map(x=><label key={x.key} className="bg-white rounded-xl p-3 flex items-center text-sm gap-2"><span className="flex-1">{T[x.key]||x.key}</span><input type="number" defaultValue={x.value} className="w-24 border rounded p-1" onBlur={e=>save(x.key,e.target.value)}/></label>)}
  <p className="text-xs text-gray-500">Changes apply to all new orders immediately.</p><Site/></div>}

const U=({o,k,...p})=><input {...p} dir="auto" defaultValue={o[k]??''} onChange={e=>{o[k]=e.target.value}} className="w-full border rounded-lg p-2 text-sm"/>;
const useT=(t,o='id')=>{const[l,setL]=useState([]);const load=()=>sb.from(t).select('*').order(o,{ascending:false}).then(({data})=>setL(data||[]));useEffect(()=>{load()},[]);return[l,load]};
const run=async(q,load)=>{const{data,error}=await q.select();error?alert(error.message):!data?.length?alert('NOT saved: no permission'):load&&load()};
const RowB=({children})=><div className="bg-white rounded-xl p-2 text-sm flex items-center gap-2 flex-wrap">{children}</div>;
function Cats(){const[l,load]=useT('categories','sort');const n=useRef({name:'',name_ur:'',icon:'📦'}).current;const[rev,setRev]=useState(0);
 return<div className="space-y-2"><div className="bg-white rounded-xl p-3 space-y-1"><U key={'a'+rev} o={n} k="name" placeholder="Category name e.g. Namak"/><U key={'b'+rev} o={n} k="name_ur" placeholder="Urdu name"/><U key={'c'+rev} o={n} k="icon" placeholder="Icon (emoji)"/><Btn c={G} onClick={()=>run(sb.from('categories').insert({name:n.name,name_ur:n.name_ur,icon:n.icon||'📦'}),load).then(()=>{n.name='';n.name_ur='';n.icon='📦';setRev(r=>r+1)})}>Add category</Btn></div>
 {l.map(c=><RowB key={c.id}><input defaultValue={c.icon} className="w-12 border rounded p-1 text-center" onBlur={e=>run(sb.from('categories').update({icon:e.target.value}).eq('id',c.id),load)}/><b className="flex-1">{c.name}{c.hidden&&' (hidden)'}</b><Btn c="border" onClick={()=>run(sb.from('categories').update({hidden:!c.hidden}).eq('id',c.id),load)}>{c.hidden?'Show':'Hide'}</Btn><Btn c="text-red-600" onClick={()=>confirm('Delete category?')&&run(sb.from('categories').delete().eq('id',c.id),load)}>Del</Btn></RowB>)}</div>}

function Riders(){const[l,load]=useT('riders');const[n,setN]=useState({name:'',phone:'',bike_no:''});const u=k=>e=>setN({...n,[k]:e.target.value});const st=(id,p)=>run(sb.from('riders').update({...p,updated_at:new Date().toISOString()}).eq('id',id),load);
 return<div className="space-y-2"><div className="bg-white rounded-xl p-3 space-y-1"><In placeholder="Rider name" value={n.name} onChange={u('name')}/><In placeholder="Phone" value={n.phone} onChange={u('phone')}/><In placeholder="Bike number" value={n.bike_no} onChange={u('bike_no')}/><Btn c={G} onClick={()=>run(sb.from('riders').insert(n),load).then(()=>setN({name:'',phone:'',bike_no:''}))}>Add rider</Btn></div>
 {l.map(r=><div key={r.id} className="bg-white rounded-xl p-2 text-sm space-y-1"><b>{r.name}</b> · {r.phone} · {r.bike_no}<div className="flex gap-1">{['available','busy','offline'].map(x=><Btn key={x} c={r.status===x?G:'border'} onClick={()=>st(r.id,{status:x})}>{x}</Btn>)}<Btn c="text-red-600" onClick={()=>confirm('Delete rider?')&&run(sb.from('riders').delete().eq('id',r.id),load)}>Del</Btn></div><In placeholder="Last location (e.g. College Road)" defaultValue={r.location||''} onBlur={e=>st(r.id,{location:e.target.value})}/><span className="text-xs text-gray-500">Updated {new Date(r.updated_at).toLocaleString()}</span></div>)}</div>}
function Deals(){const[l,load]=useT('deals');const[ps,setPs]=useState([]);const[d,setD]=useState({product_id:'',price:'',delay:'0',hours:'2'});const u=k=>e=>setD({...d,[k]:e.target.value});
 useEffect(()=>{sb.from('products').select('id,name_en,retail_price').order('name_en').then(({data})=>setPs(data||[]))},[]);
 const add=()=>{if(!d.product_id||!d.price)return alert('Choose product and price');const s=new Date(Date.now()+d.delay*36e5),e=new Date(+s+d.hours*36e5);run(sb.from('deals').insert({product_id:+d.product_id,price:+d.price,starts_at:s.toISOString(),ends_at:e.toISOString()}),load)};
 return<div className="space-y-2"><div className="bg-white rounded-xl p-3 space-y-1"><b className="text-sm">Flash deal / Sale period</b><select className="w-full border rounded-lg p-2 text-sm" value={d.product_id} onChange={u('product_id')}><option value="">Choose product</option>{ps.map(p=><option key={p.id} value={p.id}>{p.name_en} (Rs. {p.retail_price})</option>)}</select><In type="number" placeholder="Deal price (Rs.)" value={d.price} onChange={u('price')}/><In type="number" placeholder="Start after (hours, 0 = now)" value={d.delay} onChange={u('delay')}/><In type="number" placeholder="Lasts (hours: 2 flash, 24 day, 168 week)" value={d.hours} onChange={u('hours')}/><Btn c={G} onClick={add}>Start deal</Btn></div>
 {l.map(x=><RowB key={x.id}><span className="flex-1">{ps.find(p=>p.id===x.product_id)?.name_en||x.product_id} → Rs. {x.price}<br/><span className="text-xs text-gray-500">{new Date(x.starts_at).toLocaleString()} – {new Date(x.ends_at).toLocaleString()}</span></span><Btn c="border" onClick={()=>run(sb.from('deals').update({active:!x.active}).eq('id',x.id),load)}>{x.active?'Stop':'Resume'}</Btn><Btn c="text-red-600" onClick={()=>run(sb.from('deals').delete().eq('id',x.id),load)}>Del</Btn></RowB>)}</div>}
function Banners(){const[l,load]=useT('banners');const[t,setT]=useState('');
 const up=async f=>{const p=`banner-${Date.now()}-${f.name}`;const{error}=await sb.storage.from('products').upload(p,f);if(error)return alert(error.message);run(sb.from('banners').insert({title:t,image:sb.storage.from('products').getPublicUrl(p).data.publicUrl}),load)};
 return<div className="space-y-2"><div className="bg-white rounded-xl p-3 space-y-1"><In placeholder="Offer text (optional)" value={t} onChange={e=>setT(e.target.value)}/><input type="file" accept="image/*" onChange={e=>e.target.files[0]&&up(e.target.files[0])}/></div>
 {l.map(b=><RowB key={b.id}><img src={b.image} className="w-20 h-12 object-cover rounded"/><b className="flex-1">{b.title}</b><Btn c={b.active?G:'border'} onClick={()=>run(sb.from('banners').update({active:!b.active}).eq('id',b.id),load)}>{b.active?'ON':'OFF'}</Btn><Btn c="text-red-600" onClick={()=>run(sb.from('banners').delete().eq('id',b.id),load)}>Del</Btn></RowB>)}</div>}
function Notify(){const[l,load]=useT('notifications');const n=useRef({title:'',body:''}).current;const[rev,setRev]=useState(0);
 return<div className="space-y-2"><div className="bg-white rounded-xl p-3 space-y-1"><U key={'t'+rev} o={n} k="title" placeholder="Title e.g. Aaj Aata par 10% OFF"/><U key={'b'+rev} o={n} k="body" placeholder="Message"/><Btn c={G} onClick={()=>run(sb.from('notifications').insert({title:n.title,body:n.body}),load).then(()=>{n.title='';n.body='';setRev(r=>r+1)})}>Send to all customers</Btn><p className="text-xs text-gray-500">Shown at the top of the home page. Phone push alerts need Firebase (next step).</p></div>
 {l.map(x=><RowB key={x.id}><span className="flex-1"><b>{x.title}</b> {x.body}</span><Btn c="text-red-600" onClick={()=>run(sb.from('notifications').delete().eq('id',x.id),load)}>Del</Btn></RowB>)}</div>}

function Reviews(){const[l,load]=useT('reviews');return<div className="space-y-2">{!l.length&&<p>No reviews yet.</p>}{l.map(x=><RowB key={x.id}><span className="flex-1">{'⭐'.repeat(x.stars)} product #{x.product_id}: {x.comment}</span><Btn c="text-red-600" onClick={()=>run(sb.from('reviews').delete().eq('id',x.id),load)}>Delete</Btn></RowB>)}</div>}
function Complaints(){const[l,load]=useT('complaints');const st=async(x,v)=>{await run(sb.from('complaints').update({status:v}).eq('id',x.id),load);if(v==='accepted'&&x.kind==='return')await sb.from('orders').update({status:'Refunded'}).eq('id',x.order_id)};
 return<div className="space-y-2">{!l.length&&<p>No complaints or returns.</p>}{l.map(x=><RowB key={x.id}><span className="flex-1"><b>{x.kind}</b> · order #{x.order_id} · {x.status}<br/>{x.message}</span>{x.status==='open'&&<><Btn c={G} onClick={()=>st(x,'accepted')}>Accept</Btn><Btn c="text-red-600" onClick={()=>st(x,'rejected')}>Reject</Btn></>}</RowB>)}</div>}
const Bars=({a})=><div>{a.map(([k,v])=><div key={k} className="flex items-center gap-2 text-xs"><span className="w-24 truncate">{k}</span><div className="flex-1 bg-gray-200 rounded h-2"><div className="bg-green-600 h-2 rounded" style={{width:(v/Math.max(1,...a.map(x=>x[1]))*100)+'%'}}/></div><b>{Math.round(v)}</b></div>)}</div>;
function Stats(){const[O,setO]=useState([]);const[P,setP]=useState([]);useEffect(()=>{sb.from('orders').select('total,items,created_at,status').not('status','in','(Cancelled,Refunded)').limit(3000).then(({data})=>setO(data||[]));sb.from('products').select('name_en,stock_qty').lt('stock_qty',5).then(({data})=>setP(data||[]))},[]);
 const d0=new Date().setHours(0,0,0,0),sum=n=>O.filter(o=>new Date(o.created_at)>=d0-(n-1)*864e5).reduce((a,o)=>a+Number(o.total),0),days=[...Array(7)].map((_,i)=>{const a=d0-(6-i)*864e5;return[new Date(a).toLocaleDateString('en',{weekday:'short'}),O.filter(o=>{const t=+new Date(o.created_at);return t>=a&&t<a+864e5}).reduce((s,o)=>s+Number(o.total),0)]}),tp={};O.forEach(o=>o.items.forEach(i=>tp[i.name]=(tp[i.name]||0)+i.qty));
 return<div className="space-y-3"><div className="grid grid-cols-3 gap-2">{[['Today',1],['7 days',7],['30 days',30]].map(([l,n])=><div key={l} className="bg-white rounded-xl p-3"><div className="text-xs text-gray-500">{l}</div><b className="text-green-600">{rs(sum(n))}</b></div>)}</div>
 <b>Daily sale (7 days)</b><Bars a={days}/><b>Most selling</b><Bars a={Object.entries(tp).sort((a,b)=>b[1]-a[1]).slice(0,6)}/><b className="text-red-600">⚠️ Low stock (under 5)</b>{P.map(p=><div key={p.name_en} className="text-sm">{p.name_en}: {p.stock_qty}</div>)}{!P.length&&<p className="text-sm">All stocked.</p>}<p className="text-xs text-gray-500">Out-of-stock products are hidden from customers automatically.</p></div>}
function Site(){const[t,setT]=useState({});const[staff,setStaff]=useState([]);const[em,setEm]=useState('');const[role,setRole]=useState('manager');
 const load=()=>{sb.from('app_text').select('*').then(({data})=>setT(Object.fromEntries((data||[]).map(x=>[x.key,x.value]))));sb.from('profiles').select('email,role').in('role',['admin','manager']).then(({data})=>setStaff(data||[]))};useEffect(()=>{load()},[]);
 const sv=(k,v)=>run(sb.from('app_text').upsert({key:k,value:v}),load);
 const logo=async f=>{const p=`logo-${Date.now()}-${f.name}`;const{error}=await sb.storage.from('products').upload(p,f);error?alert(error.message):sv('logo',sb.storage.from('products').getPublicUrl(p).data.publicUrl)};
 const ownerPhoto=async f=>{try{const b=await shrinkImg(f,400);const p=`owner-${Date.now()}.jpg`;const{error}=await sb.storage.from('products').upload(p,b,{contentType:'image/jpeg'});error?alert(error.message):sv('owner_photo',sb.storage.from('products').getPublicUrl(p).data.publicUrl)}catch(e){alert(e.message)}};
 const backup=async()=>{const{data,error}=await sb.rpc('backup_all');if(error)return alert(error.message);const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([JSON.stringify(data,null,1)],{type:'application/json'}));a.download='dg-bazar-backup-'+new Date().toISOString().slice(0,10)+'.json';a.click()};
 return<div className="space-y-2"><b>Shop settings</b><div className="bg-white rounded-xl p-3 space-y-1 text-sm"><b>Shop & owner details</b>{[['shop_name','Shop name'],['shop_address','Shop address'],['shop_city','City'],['shop_phone','Shop phone'],['owner_name','Owner name'],['owner_phone','Owner phone'],['owner_email','Owner email']].map(([k,l])=><label key={k+(t[k]||'')} className="block">{l}<In defaultValue={t[k]||''} onBlur={e=>sv(k,e.target.value.trim())}/></label>)}<label className="block">Owner photo<input type="file" accept="image/*" onChange={e=>{const f=e.target.files[0];e.target.value='';f&&ownerPhoto(f)}}/>{t.owner_photo&&<img src={t.owner_photo} className="w-16 h-16 rounded-full object-cover mt-1"/>}</label></div><label className="bg-white rounded-xl p-3 block text-sm">WhatsApp number (92...)<In key={'w'+(t.whatsapp||'')} defaultValue={t.whatsapp||''} onBlur={e=>sv('whatsapp',e.target.value.trim())}/></label>
 <label className="bg-white rounded-xl p-3 block text-sm">Logo image<input type="file" accept="image/*" onChange={e=>e.target.files[0]&&logo(e.target.files[0])}/>{t.logo&&<img src={t.logo} className="h-10 mt-1"/>}</label>
 <div className="bg-white rounded-xl p-3 text-sm space-y-1"><b>Opening hours: {t.auto_hours==='on'?'AUTO ON 🟢':'OFF (always open)'}</b><div className="flex gap-2 items-center flex-wrap">Open<input type="time" key={'o'+(t.open_time||'')} defaultValue={t.open_time||'09:00'} className="border rounded p-1" onBlur={e=>sv('open_time',e.target.value)}/>Close<input type="time" key={'c'+(t.close_time||'')} defaultValue={t.close_time||'22:00'} className="border rounded p-1" onBlur={e=>sv('close_time',e.target.value)}/></div>
 <div className="flex flex-wrap gap-1">{['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].map((d,i)=>{const off=(t.closed_days||'').split(',').includes(String(i));return<Btn key={d} c={off?'bg-red-600 text-white':'border'} onClick={()=>{const z=new Set((t.closed_days||'').split(',').filter(Boolean));off?z.delete(String(i)):z.add(String(i));sv('closed_days',[...z].join(','))}}>{d}{off?' off':''}</Btn>})}</div>
 <Btn c={t.auto_hours==='on'?'border':G} onClick={()=>sv('auto_hours',t.auto_hours==='on'?'off':'on')}>{t.auto_hours==='on'?'Turn auto hours OFF':'Turn auto hours ON'}</Btn><p className="text-xs text-gray-500">Pakistan time. Red days = closed all day. Outside hours customers can browse but cannot order.</p></div>
 <div className="bg-white rounded-xl p-3 text-sm space-y-1"><b>Maintenance mode: {t.maintenance==='on'?'ON 🔴':'OFF 🟢'}</b><In key={'m'+(t.maintenance_msg||'')} placeholder="Message e.g. Dukan Band Hai" defaultValue={t.maintenance_msg||''} onBlur={e=>sv('maintenance_msg',e.target.value)}/><Btn c={t.maintenance==='on'?G:'bg-red-600 text-white'} onClick={()=>sv('maintenance',t.maintenance==='on'?'off':'on')}>{t.maintenance==='on'?'Open the shop':'Close the shop'}</Btn></div>
 <div className="bg-white rounded-xl p-3 text-sm space-y-1"><b>Staff (super admin only)</b>{staff.map(x=><div key={x.email}>{x.email} · {x.role}</div>)}<In placeholder="Registered user's email" value={em} onChange={e=>setEm(e.target.value)}/><select className="w-full border rounded-lg p-2" value={role} onChange={e=>setRole(e.target.value)}><option value="manager">Manager</option><option value="admin">Super admin</option><option value="customer">Remove access</option></select><Btn c={G} onClick={async()=>{const{error}=await sb.rpc('set_role_by_email',{p_email:em.trim(),p_role:role});error?alert(error.message):(setEm(''),load())}}>Save role</Btn></div>
 <Btn c={G+' w-full'} onClick={backup}>⬇ Download full database backup</Btn></div>}
function Slider(){const{t}=useA();const[b,setB]=useState([]);const[n,setN]=useState(null);const[i,setI]=useState(0);
 useEffect(()=>{sb.from('banners').select('*').eq('active',true).order('id',{ascending:false}).then(({data})=>setB(data||[]));sb.from('notifications').select('*').order('id',{ascending:false}).limit(1).then(({data})=>setN(data?.[0]||null))},[]);
 useEffect(()=>{if(b.length<2)return;const k=setInterval(()=>setI(x=>(x+1)%b.length),4000);return()=>clearInterval(k)},[b]);const x=b[i%(b.length||1)];
 return<>{!isOpen()&&<div className="bg-red-100 text-red-800 rounded-xl p-2 text-sm font-bold">🔒 {TXT.maintenance_msg||'Dukan abhi band hai'} — Hours: {TXT.open_time||'09:00'} to {TXT.close_time||'22:00'} (Pakistan time)</div>}
  {n&&Date.now()-new Date(n.created_at)<3*864e5&&<div className="bg-amber-100 text-amber-900 rounded-xl p-2 text-sm">📢 <b>{n.title}</b> {n.body}</div>}
  {x?<div className="relative rounded-3xl overflow-hidden"><img src={x.image} className="w-full h-48 object-cover"/>{x.title&&<div className="absolute bottom-6 inset-x-0 text-white font-bold text-center px-3 py-1 bg-black/30">{x.title}</div>}{b.length>1&&<div className="absolute bottom-2 inset-x-0 flex justify-center gap-1">{b.map((_,j)=><i key={j} className={`h-2 rounded-full ${j===i%b.length?'w-8 bg-white':'w-2 bg-white/60'}`}/>)}</div>}</div>
  :<div className="rounded-3xl p-6 text-white bg-gradient-to-r from-green-700 to-green-500"><h1 className="font-extrabold text-2xl">{t.banner}</h1></div>}</>}

const complain=async(o,kind)=>{const m=prompt(kind==='return'?'Why do you want to return?':'Write your complaint');if(!m)return;const{error}=await sb.from('complaints').insert({order_id:o.id,kind,message:m,user_id:o.user_id});alert(error?error.message:'Sent to DG Bazar ✓')};
const review=async pid=>{const st=+prompt('Stars (1-5)');if(!(st>=1&&st<=5))return;const c=prompt('Your review')||'';const{data:u}=await sb.auth.getUser();const{error}=await sb.from('reviews').upsert({product_id:pid,user_id:u.user.id,stars:st,comment:c},{onConflict:'product_id,user_id'});alert(error?error.message:'Thanks ✓')};

const shrinkImg=(f,max=700)=>new Promise((ok,no)=>{const rd=new FileReader;rd.onload=()=>{const i=new Image;i.onload=()=>{const k=Math.min(1,max/Math.max(i.width,i.height)),c=document.createElement('canvas');c.width=i.width*k;c.height=i.height*k;c.getContext('2d').drawImage(i,0,0,c.width,c.height);c.toBlob(b=>b?ok(b):no(new Error('compress failed')),'image/jpeg',.8)};i.onerror=()=>no(new Error('not an image'));i.src=rd.result};rd.onerror=()=>no(new Error('read failed'));rd.readAsDataURL(f)});

function About(){const{setPage}=useA();const addr=[TXT.shop_address,TXT.shop_city].filter(Boolean).join(', ')||'Sadar Bazaar, Dera Ghazi Khan',ph=TXT.shop_phone||TXT.owner_phone||'+'+WA;
 return<main className="max-w-md mx-auto p-4 space-y-3"><button onClick={()=>setPage('home')} className="text-green-600 font-semibold">← Back</button><h2 className="text-2xl font-extrabold">{TXT.shop_name||'DG Bazar'}</h2>
  <div className="bg-white border rounded-2xl p-4 text-sm space-y-2"><div>📍 <b>Shop address</b><br/>{addr}</div><div className="flex items-center gap-3">{TXT.owner_photo&&<img src={TXT.owner_photo} className="w-20 h-20 rounded-full object-cover"/>}<div>👤 <b>Owner</b><br/>{TXT.owner_name||'-'}</div></div><div>📞 <b>Phone</b><br/>{ph}</div>{TXT.owner_email&&<div>✉️ {TXT.owner_email}</div>}<div>🕒 <b>Hours</b><br/>{TXT.auto_hours==='on'?(TXT.open_time||'09:00')+' to '+(TXT.close_time||'22:00')+' (Pakistan time)':'Open all day'}</div></div>
  <a className="block text-center bg-green-600 text-white font-bold rounded-2xl py-3" href={`tel:${ph.replace(/[^+\d]/g,'')}`}>📞 Call shop</a>
  <a target="_blank" className="block text-center bg-amber-100 text-amber-900 font-bold rounded-2xl py-3" href={`https://wa.me/${WA}`}>💬 WhatsApp</a>
  <a target="_blank" className="block text-center border font-bold rounded-2xl py-3" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(addr)}`}>🗺️ Open in Maps</a></main>}

const Avatar=({url,name,size=40})=>url?<img src={url} className="rounded-full object-cover" style={{width:size,height:size}}/>:<span className="rounded-full bg-green-100 text-green-700 font-bold grid place-items-center" style={{width:size,height:size}}>{(name||'?')[0].toUpperCase()}</span>;
const setAvatar=async(uid,f)=>{try{const b=await shrinkImg(f,320);const path=`${uid}/${Date.now()}.jpg`;const{error}=await sb.storage.from('avatars').upload(path,b,{contentType:'image/jpeg'});if(error)return alert(error.message);const{error:e2}=await sb.rpc('set_avatar',{p_url:sb.storage.from('avatars').getPublicUrl(path).data.publicUrl});e2?alert(e2.message):window.refreshProfile&&window.refreshProfile()}catch(e){alert('Photo failed: '+e.message)}};
