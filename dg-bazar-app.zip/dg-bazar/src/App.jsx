import{useState,useEffect,useMemo,createContext,useContext}from'react';
import{createClient}from'@supabase/supabase-js';
const sb=createClient(import.meta.env.VITE_SUPABASE_URL,import.meta.env.VITE_SUPABASE_ANON_KEY);
const WA=import.meta.env.VITE_WHATSAPP||'923000000000';
const CITIES=['DG Khan','Multan','Lahore','Karachi','Islamabad','Bahawalpur','Faisalabad','Rawalpindi','Peshawar','Quetta','Sialkot','Gujranwala'];
const PUNJAB=['Multan','Lahore','Bahawalpur','Faisalabad','Rawalpindi','Sialkot','Gujranwala'];
const AREAS=['Sadar Bazaar','Kot Chutta','Taunsa Road','College Road','Block 1-10','Other'];
const CATS={Atta:['🌾','آٹا'],Cheeni:['🍚','چینی'],'Ghee/Oil':['🛢️','گھی/تیل'],Daalain:['🫘','دالیں'],Chawal:['🍛','چاول'],Soap:['🧼','صابن'],Masala:['🌶️','مصالحہ'],Chai:['🍵','چائے'],Dairy:['🥛','ڈیری']};
const T={ur:{search:'تلاش کریں',add:'کارٹ میں ڈالیں',login:'لاگ ان',banner:'ڈی جی خان سے پورے پاکستان تک - سستا کریانہ گھر تک',cart:'کارٹ',dukan:'دکان ریٹ',pcs:'عدد پر',total:'کل',place:'آرڈر کریں',all:'سب'},
 en:{search:'Search products',add:'Add to Cart',login:'Login',banner:'DG Khan Se Pooray Pakistan Tak - Sasta Karyana Ghar Tak',cart:'Cart',dukan:'Dukan Price',pcs:'pcs',total:'Total',place:'Place Order',all:'All'}};
const Ctx=createContext();const useA=()=>useContext(Ctx);
const norm=p=>'+92'+p.replace(/\D/g,'').replace(/^(92|0)/,'');const ST=['Pending','Packed','Shipped','Delivered'];
const rs=n=>'Rs. '+Math.round(n).toLocaleString();
const delivery=c=>c==='DG Khan'?99:PUNJAB.includes(c)?199:250;
const Btn=({c='',...p})=><button {...p} className={`rounded-lg px-3 py-2 font-semibold text-sm active:scale-95 transition ${c}`}/>;
const In=p=><input {...p} className="w-full border rounded-lg p-2 text-sm"/>;
const G='bg-green-600 text-white hover:bg-green-700';

export default function App(){
 const[lang,setLang]=useState(localStorage.lang||'en');const[city,setCity]=useState(localStorage.city);
 const[user,setUser]=useState(null);const[profile,setProfile]=useState(null);const[cart,setCart]=useState({});
 const[products,setProducts]=useState([]);const[modal,setModal]=useState(null);const[page,setPage]=useState('home');
 const t=T[lang];
 const loadP=async u=>{if(!u)return setProfile(null);const{data}=await sb.from('profiles').select('*').eq('id',u.id).maybeSingle();setProfile(data);if(!data&&!u.email)setModal('signup')};
 useEffect(()=>{sb.auth.getSession().then(({data})=>{setUser(data.session?.user??null);loadP(data.session?.user)});
  const{data:l}=sb.auth.onAuthStateChange((_,s)=>{setUser(s?.user??null);loadP(s?.user)});return()=>l.subscription.unsubscribe()},[]);
 useEffect(()=>{sb.from('products').select('*').order('id').then(({data})=>setProducts(data||[]))},[]);
 const isWS=profile?.type==='wholesale'&&profile?.status==='approved';
 const price=(p,q)=>isWS&&q>=p.wholesale_moq?p.wholesale_price:p.retail_price;
 const lines=useMemo(()=>Object.entries(cart).map(([id,q])=>{const p=products.find(x=>x.id==id);return p&&{p,q,unit:price(p,q),ws:isWS&&q>=p.wholesale_moq}}).filter(Boolean),[cart,products,isWS]);
 const subtotal=lines.reduce((s,l)=>s+l.unit*l.q,0),saved=lines.reduce((s,l)=>s+(l.ws?(l.p.retail_price-l.unit)*l.q:0),0);
 const setQ=(id,q)=>setCart(c=>{const n={...c};q<=0?delete n[id]:n[id]=q;return n});
 const ctx={lang,t,city,user,profile,modal,isWS,cart,setQ,lines,subtotal,saved,setModal,setPage,price};
 if(location.pathname.startsWith('/admin'))return<Ctx.Provider value={ctx}><Admin/></Ctx.Provider>;
 return<Ctx.Provider value={ctx}><div dir={lang==='ur'?'rtl':'ltr'} className={`min-h-screen bg-gray-50 ${lang==='ur'?'ur':''}`}>
  {!city&&<CityModal onPick={c=>{localStorage.city=c;setCity(c)}}/>}
  <header className="bg-white sticky top-0 z-10 shadow-sm p-3 flex flex-wrap gap-2 items-center">
   <b className="text-green-600 text-xl cursor-pointer" onClick={()=>setPage('home')}>🛒 DG Bazar</b>
   <button className="text-xs border rounded-full px-2 py-1" onClick={()=>{localStorage.removeItem('city');setCity(null)}}>📍 {city}</button>
   <div className="flex-1 order-last w-full md:order-none md:w-auto"><Search/></div>
   <Btn c="border" onClick={()=>{const l=lang==='ur'?'en':'ur';localStorage.lang=l;setLang(l)}}>{lang==='ur'?'EN':'اردو'}</Btn>
   <Install/><Btn c={G} onClick={()=>setPage('cart')}>{t.cart} ({lines.length})</Btn>
   {profile?.role==='admin'&&<a className="text-xs underline" href="/admin">Admin</a>}{user&&<Btn c="border" onClick={()=>setPage('myo')}>📦</Btn>}{user?<Btn c="border" onClick={()=>sb.auth.signOut()}>Logout</Btn>:<><Btn c="border" onClick={()=>setPage('register')}>Register</Btn><Btn c="border" onClick={()=>setModal('login')}>{t.login}</Btn></>}
  </header>
  {modal==='login'&&<Login/>}{modal==='signup'&&<Signup/>}
  {page==='home'?<Home products={products}/>:page==='cart'?<Cart/>:page==='myo'?<MyOrders/>:page==='register'?<Register/>:<Checkout/>}
  <footer className="bg-green-700 text-white text-sm p-6 mt-10"><b>DG Bazar Warehouse</b><br/>Sadar Bazaar, Dera Ghazi Khan · 📞 +{WA}<br/>Delivering All Pakistan via TCS / Leopards</footer>
 </div></Ctx.Provider>}

const SearchCtx=createContext();let setSearchG=()=>{};
function Search(){const{t}=useA();return<input className="w-full border rounded-full px-4 py-2 text-sm" placeholder={t.search} onChange={e=>setSearchG(e.target.value)}/>}
function CityModal({onPick}){return<div className="fixed inset-0 bg-black/60 z-50 grid place-items-center p-4"><div className="bg-white rounded-2xl p-5 max-w-md w-full">
 <h2 className="font-extrabold text-green-600 text-lg mb-3">Apna Shehar Chunein / Select City</h2>
 <div className="grid grid-cols-2 gap-2">{CITIES.map(c=><Btn key={c} c="border hover:bg-green-50" onClick={()=>onPick(c)}>{c}</Btn>)}</div></div></div>}

function Home({products}){const{t,city,lang}=useA();const[cat,setCat]=useState('');const[q,setQ]=useState('');setSearchG=setQ;
 const list=products.filter(p=>(!cat||p.category===cat)&&(p.name_en+p.name_ur).toLowerCase().includes(q.toLowerCase()));
 return<main className="max-w-6xl mx-auto p-3">
  <div className="bg-gradient-to-r from-green-600 to-green-500 text-white rounded-2xl p-5 mb-4"><h1 className="font-extrabold text-xl md:text-3xl">{t.banner}</h1>
   <span className="inline-block mt-2 bg-white text-green-700 text-xs font-bold rounded-full px-3 py-1">{city==='DG Khan'?'⚡ 2-Hour Delivery':'🚚 2-3 Days via TCS/Leopards'} · {rs(delivery(city))}</span></div>
  <div className="grid grid-cols-4 md:grid-cols-9 gap-2 mb-4">{[['',['🏪',t.all]],...Object.entries(CATS)].map(([k,[e,u]])=>
   <button key={k} onClick={()=>setCat(k)} className={`rounded-xl p-2 text-center text-xs ${cat===k?'bg-green-600 text-white':'bg-white'}`}><div className="text-2xl">{e}</div>{lang==='ur'?u:k||t.all}</button>)}</div>
  <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3">{list.map(p=><Card key={p.id} p={p}/>)}</div></main>}

function Card({p}){const{t,lang,cart,setQ,isWS}=useA();const q=cart[p.id]||0;
 const wa=`https://wa.me/${WA}?text=${encodeURIComponent(`Order: ${p.name_en} (${rs(p.retail_price)})`)}`;
 return<div className="bg-white rounded-xl shadow-sm p-2 flex flex-col">
  <div className="aspect-square bg-green-50 rounded-lg grid place-items-center overflow-hidden">{p.image_url?<img src={p.image_url} alt={p.name_en} loading="lazy" className="object-cover w-full h-full"/>:<span className="text-5xl">{CATS[p.category]?.[0]||'📦'}</span>}</div>
  <div className="text-sm font-semibold mt-2 leading-tight">{p.name_en}</div><div className="ur text-xs text-gray-500">{p.name_ur}</div>
  <div className="text-green-700 font-extrabold">{rs(p.retail_price)}<span className="text-xs font-normal text-gray-400">/{p.unit}</span></div>
  <span className="text-[11px] bg-green-100 text-green-700 rounded px-1.5 py-0.5 w-fit">{t.dukan}: {rs(p.wholesale_price)} {lang==='ur'?'':'on'} {p.wholesale_moq} {t.pcs}</span>
  {isWS&&q>=p.wholesale_moq&&<span className="text-[11px] text-green-700 font-bold">✅ Wholesale Price Applied!</span>}
  <div className="mt-auto pt-2 space-y-1">{q?<div className="flex items-center justify-between"><Btn c="border" onClick={()=>setQ(p.id,q-1)}>−</Btn><b>{q}</b><Btn c={G} onClick={()=>setQ(p.id,q+1)}>+</Btn></div>
   :<Btn c={G+' w-full'} onClick={()=>setQ(p.id,1)}>{t.add}</Btn>}
   <a href={wa} target="_blank" className="block text-center text-xs border border-green-600 text-green-700 rounded-lg py-1.5">Order on WhatsApp</a></div></div>}

function Cart(){const{lines,subtotal,saved,setQ,setPage,city,t}=useA();
 return<main className="max-w-2xl mx-auto p-3 space-y-2"><h2 className="font-extrabold text-lg">{t.cart}</h2>
  {!lines.length&&<p>Cart is empty.</p>}
  {lines.map(({p,q,unit,ws})=><div key={p.id} className="bg-white rounded-xl p-3 flex items-center gap-3"><div className="flex-1"><div className="font-semibold text-sm">{p.name_en}</div>
   <div className="text-xs">{rs(unit)} × {q} {ws&&<span className="text-green-700 font-bold">Wholesale Price Applied!</span>}</div></div>
   <Btn c="border" onClick={()=>setQ(p.id,q-1)}>−</Btn><b>{q}</b><Btn c={G} onClick={()=>setQ(p.id,q+1)}>+</Btn></div>)}
  {saved>0&&<div className="bg-green-100 text-green-800 rounded-xl p-3 font-bold">🎉 You save {rs(saved)}</div>}
  <div className="bg-white rounded-xl p-3 text-sm">Subtotal {rs(subtotal)}<br/>Delivery ({city}) {rs(delivery(city))}<br/><b className="text-lg">{t.total}: {rs(subtotal+delivery(city))}</b></div>
  {lines.length>0&&<Btn c={G+' w-full'} onClick={()=>setPage('checkout')}>Checkout</Btn>}</main>}

function Checkout(){const{lines,subtotal,city,user,setPage,setModal,t}=useA();const[f,setF]=useState({name:'',phone:'',area:'',address:'',payment:'COD'});const[busy,setBusy]=useState(false);const[done,setDone]=useState(null);
 const u=k=>e=>setF({...f,[k]:e.target.value});
 const place=async()=>{if(!user)return setModal('login');if(!f.name||!f.phone||!f.address)return alert('Please fill all fields');setBusy(true);
  const{data,error}=await sb.rpc('place_order',{p_items:lines.map(l=>({id:l.p.id,qty:l.q})),p_cust:{...f,city},p_coupon:f.coupon||null});
  setBusy(false);error?alert(error.message):setDone(data)};
 if(done)return<main className="p-6 text-center"><h2 className="text-2xl font-extrabold text-green-600">Order #{done} placed ✅</h2><Btn c={G+' mt-4'} onClick={()=>location.reload()}>Continue Shopping</Btn></main>;
 return<main className="max-w-md mx-auto p-3 space-y-2"><h2 className="font-extrabold text-lg">Checkout</h2>
  <In placeholder="Full Name" value={f.name} onChange={u('name')}/><In placeholder="Phone (03XX...)" value={f.phone} onChange={u('phone')}/><In value={city} disabled/>
  {city==='DG Khan'&&<select className="w-full border rounded-lg p-2 text-sm" value={f.area} onChange={u('area')}><option value="">Select Area</option>{AREAS.map(a=><option key={a}>{a}</option>)}</select>}
  <textarea className="w-full border rounded-lg p-2 text-sm" placeholder="Full Address" value={f.address} onChange={u('address')}/>
  {['COD','Easypaisa','JazzCash'].map(m=><label key={m} className="flex gap-2 bg-white rounded-lg p-2 text-sm"><input type="radio" checked={f.payment===m} onChange={()=>setF({...f,payment:m})}/>{m}{m==='COD'&&' (Cash on Delivery)'}</label>)}
  <In placeholder="Coupon: DGKHAN50 / RASHAN10 / friend's invite code" value={f.coupon||''} onChange={u('coupon')}/><Btn c={G+' w-full'} disabled={busy} onClick={place}>{t.place} · {rs(subtotal+delivery(city))}</Btn></main>}

function Login(){const{setModal,setPage}=useA();const[mode,setMode]=useState('phone');const[id,setId]=useState('');const[otp,setOtp]=useState('');const[sent,setSent]=useState(false);const[busy,setBusy]=useState(false);
 const tgt=()=>mode==='phone'?{phone:norm(id)}:{email:id.trim().toLowerCase()};
 const send=async()=>{setBusy(true);const{error}=await sb.auth.signInWithOtp({...tgt(),...(mode==='email'?{options:{shouldCreateUser:false}}:{})});setBusy(false);
  error?alert(mode==='email'&&/signup/i.test(error.message)?'No account with this email. Please Register first.':error.message):setSent(true)};
 const verify=async()=>{setBusy(true);const{error}=await sb.auth.verifyOtp({...tgt(),token:otp.trim(),type:mode==='phone'?'sms':'email'});setBusy(false);error?alert(error.message):setModal(null)};
 return<Sheet title="Login" close={()=>setModal(null)}>
  <div className="flex gap-2">{[['phone','📱 Phone'],['email','✉️ Email']].map(([k,l])=><Btn key={k} c={mode===k?G+' flex-1':'border flex-1'} onClick={()=>{setMode(k);setSent(false);setId('')}}>{l}</Btn>)}</div>
  {!sent?<><In placeholder={mode==='phone'?'03XX XXXXXXX':'you@email.com'} type={mode==='email'?'email':'tel'} value={id} onChange={e=>setId(e.target.value)}/><Btn c={G+' w-full'} disabled={busy} onClick={send}>Send OTP</Btn></>
  :<><p className="text-xs text-gray-500">Code sent to {id}</p><In placeholder="6-digit OTP" inputMode="numeric" maxLength={8} value={otp} onChange={e=>setOtp(e.target.value)}/><Btn c={G+' w-full'} disabled={busy} onClick={verify}>Verify & Login</Btn></>}
  <p className="text-xs text-center">New here? <button className="text-green-700 underline" onClick={()=>{setModal(null);setPage('register')}}>Create account</button></p></Sheet>}
const Sheet=({title,close,children})=><div className="fixed inset-0 bg-black/50 z-40 grid place-items-center p-4"><div className="bg-white rounded-2xl p-5 w-full max-w-sm space-y-2 max-h-[90vh] overflow-auto"><div className="flex justify-between"><b>{title}</b>{close&&<button onClick={close}>✕</button>}</div>{children}</div></div>;

function Signup(){const{user,setModal,city}=useA();const[type,setType]=useState('retail');const[s,setS]=useState({shop_name:'',shop_city:city||'',shop_address:''});const[file,setFile]=useState(null);const[busy,setBusy]=useState(false);
 const save=async()=>{setBusy(true);let card_url=null;
  if(type==='wholesale'){if(!file||!s.shop_name)return setBusy(false)||alert('Shop name and visiting card required');
   const path=`${user.id}/${Date.now()}`;const up=await sb.storage.from('shop-cards').upload(path,file);if(up.error){setBusy(false);return alert(up.error.message)}
   card_url=sb.storage.from('shop-cards').getPublicUrl(path).data.publicUrl}
  const{error}=await sb.from('profiles').insert({id:user.id,phone:user.phone,type,...(type==='wholesale'?{...s,card_url,status:'pending'}:{status:'approved'})});
  setBusy(false);error?alert(error.message):(setModal(null),location.reload())};
 return<Sheet title="Aap kaun hain?">{[['retail','Ghar ke liye (Retail Customer)'],['wholesale','Dukan ke liye (Wholesale Shopkeeper)']].map(([k,l])=>
  <label key={k} className={`flex gap-2 border rounded-lg p-2 text-sm ${type===k?'border-green-600 bg-green-50':''}`}><input type="radio" checked={type===k} onChange={()=>setType(k)}/>{l}</label>)}
  {type==='wholesale'&&<><In placeholder="Shop Name" onChange={e=>setS({...s,shop_name:e.target.value})}/><In placeholder="City" value={s.shop_city} onChange={e=>setS({...s,shop_city:e.target.value})}/>
   <In placeholder="Shop Address" onChange={e=>setS({...s,shop_address:e.target.value})}/><label className="text-xs">Shop Visiting Card (image)<input type="file" accept="image/*" onChange={e=>setFile(e.target.files[0])}/></label>
   <p className="text-xs text-amber-600">Status: pending until admin approves.</p></>}
  <Btn c={G+' w-full'} disabled={busy} onClick={save}>Continue</Btn></Sheet>}

/* ---------- ADMIN (/admin) ---------- */
function Admin(){const{user,profile,modal,setModal}=useA();const[tab,setTab]=useState('dash');const[e,setE]=useState('admin@dg-bazar.pk');const[pw,setPw]=useState('');
 if(profile?.role!=='admin')return<div className="min-h-screen grid place-items-center p-4 text-center"><div className="bg-white shadow rounded-xl p-5 space-y-2"><b>Admin Login</b><p className="text-sm">Login with the admin mobile number (OTP).</p>{user?<p className="text-red-600 text-sm">This account is not an admin.</p>:<Btn c={G} onClick={()=>setModal('login')}>Login with OTP</Btn>}{modal==='login'&&<Login/>}</div></div>;
 return<div className="max-w-5xl mx-auto p-3"><div className="flex gap-2 mb-3 flex-wrap">{[['dash','Dashboard'],['prod','Products'],['ord','Orders'],['ver','Shopkeepers'],['cus','Customers'],['cou','Coupons'],['log','Activity']].map(([k,l])=><Btn key={k} c={tab===k?G:'bg-white border'} onClick={()=>setTab(k)}>{l}</Btn>)}<a href="/" className="ml-auto text-sm underline self-center">Store</a></div>
  {tab==='dash'?<Dash/>:tab==='prod'?<Prods/>:tab==='ord'?<Orders/>:tab==='cus'?<Customers/>:tab==='cou'?<Coupons/>:tab==='log'?<Activity/>:<Verify/>}</div>}
function Dash(){const[s,setS]=useState({});useEffect(()=>{(async()=>{const day=new Date();day.setHours(0,0,0,0);
 const[a,b,c]=await Promise.all([sb.from('orders').select('id',{count:'exact',head:true}),sb.from('orders').select('total').gte('created_at',day.toISOString()),sb.from('profiles').select('id',{count:'exact',head:true}).eq('status','pending')]);
 setS({orders:a.count,today:(b.data||[]).reduce((x,o)=>x+Number(o.total),0),pend:c.count})})()},[]);
 return<div className="grid grid-cols-3 gap-3">{[['Total Orders',s.orders],['Today Sale',rs(s.today||0)],['Pending Verifications',s.pend]].map(([l,v])=><div key={l} className="bg-white rounded-xl p-4"><div className="text-xs text-gray-500">{l}</div><div className="text-2xl font-extrabold text-green-600">{v??'…'}</div></div>)}</div>}
function Prods(){const[list,setList]=useState([]);const[ed,setEd]=useState(null);const load=()=>sb.from('products').select('*').order('id').then(({data})=>setList(data||[]));useEffect(()=>{load()},[]);
 const save=async()=>{const{id,...r}=ed;['retail_price','wholesale_price','wholesale_moq','stock_qty'].forEach(k=>r[k]=Number(r[k]||0));
  const{error}=id?await sb.from('products').update(r).eq('id',id):await sb.from('products').insert(r);error?alert(error.message):(setEd(null),load())};
 const upload=async f=>{const p=`${Date.now()}-${f.name}`;const{error}=await sb.storage.from('products').upload(p,f);error?alert(error.message):setEd({...ed,image_url:sb.storage.from('products').getPublicUrl(p).data.publicUrl})};
 const F=[['name_en','Name (EN)'],['name_ur','Name (UR)'],['category','Category'],['retail_price','Retail Price'],['wholesale_price','Wholesale Price'],['wholesale_moq','MOQ'],['unit','Unit'],['stock_qty','Stock'],['barcode','Barcode']];
 return<div><Btn c={G+' mb-2'} onClick={()=>setEd({unit:'piece',wholesale_moq:12})}>+ Add Product</Btn>
  {ed&&<Sheet title="Product" close={()=>setEd(null)}>{F.map(([k,l])=><In key={k} placeholder={l} value={ed[k]??''} onChange={e=>setEd({...ed,[k]:e.target.value})}/>)}
   <input type="file" accept="image/*" onChange={e=>e.target.files[0]&&upload(e.target.files[0])}/><label className="text-sm flex gap-2"><input type="checkbox" checked={!!ed.is_featured} onChange={e=>setEd({...ed,is_featured:e.target.checked})}/>Featured</label><Btn c={G+' w-full'} onClick={save}>Save</Btn></Sheet>}
  <div className="bg-white rounded-xl overflow-x-auto"><table className="w-full text-sm"><tbody>{list.map(p=><tr key={p.id} className="border-b"><td className="p-2">{p.name_en}</td><td>{rs(p.retail_price)}</td><td>{rs(p.wholesale_price)}/{p.wholesale_moq}</td><td className={p.stock_qty<30?'text-red-600 font-bold':''}>{p.stock_qty}</td>
   <td><Btn onClick={()=>setEd(p)}>Edit</Btn><Btn c="text-red-600" onClick={async()=>{confirm('Delete?')&&(await sb.from('products').delete().eq('id',p.id),load())}}>Del</Btn></td></tr>)}</tbody></table></div></div>}
function Orders(){const[list,setList]=useState([]);const[fc,setFc]=useState('');const[fs,setFs]=useState('');
 const load=()=>{let q=sb.from('orders').select('*').order('id',{ascending:false}).limit(200);if(fc)q=q.eq('city',fc);if(fs)q=q.eq('status',fs);q.then(({data})=>setList(data||[]))};useEffect(load,[fc,fs]);
 return<div><div className="flex gap-2 mb-2"><select className="border rounded p-1 text-sm" onChange={e=>setFc(e.target.value)}><option value="">All Cities</option>{CITIES.map(c=><option key={c}>{c}</option>)}</select>
  <select className="border rounded p-1 text-sm" onChange={e=>setFs(e.target.value)}><option value="">All Status</option>{ST.map(c=><option key={c}>{c}</option>)}</select></div>
  <div className="bg-white rounded-xl overflow-x-auto"><table className="w-full text-sm"><tbody>{list.map(o=><tr key={o.id} className="border-b"><td className="p-2">#{o.id}</td><td>{o.name}<br/><span className="text-xs text-gray-500">{o.phone}</span></td><td>{o.city}</td><td>{rs(o.total)}</td><td>{o.payment}</td>
   <td><input className="border rounded p-1 w-28" placeholder="TCS/Leopards #" defaultValue={o.tracking_no||''} onBlur={async e=>{await sb.from('orders').update({tracking_no:e.target.value}).eq('id',o.id)}}/></td><td><select value={o.status} className="border rounded p-1" onChange={async e=>{await sb.from('orders').update({status:e.target.value}).eq('id',o.id);load()}}>{ST.map(c=><option key={c}>{c}</option>)}</select></td></tr>)}</tbody></table></div></div>}
function Verify(){const[list,setList]=useState([]);const load=()=>sb.from('profiles').select('*').eq('status','pending').eq('type','wholesale').then(({data})=>setList(data||[]));useEffect(()=>{load()},[]);
 const set=async(id,status)=>{await sb.from('profiles').update({status}).eq('id',id);load()};
 return<div className="grid md:grid-cols-2 gap-3">{!list.length&&<p>No pending shopkeepers.</p>}{list.map(p=><div key={p.id} className="bg-white rounded-xl p-3 space-y-1"><b>{p.shop_name}</b><div className="text-xs">{p.shop_city} · {p.shop_address} · {p.phone}</div>
  <a href={p.card_url} target="_blank"><img src={p.card_url} className="h-32 rounded object-cover"/></a><div className="flex gap-2"><Btn c={G} onClick={()=>set(p.id,'approved')}>Approve</Btn><Btn c="bg-red-600 text-white" onClick={()=>set(p.id,'rejected')}>Reject</Btn></div></div>)}</div>}

function MyOrders(){const{user}=useA();const[l,setL]=useState([]);
 useEffect(()=>{sb.from('orders').select('*').eq('user_id',user.id).order('id',{ascending:false}).limit(20).then(({data})=>setL(data||[]))},[]);
 return<main className="max-w-lg mx-auto p-3 space-y-2"><h2 className="font-extrabold text-lg">📦 My Orders</h2>{!l.length&&<p>No orders yet.</p>}
  {l.map(o=><div key={o.id} className="bg-white rounded-xl p-3 text-sm"><b>#{o.id}</b> · {rs(o.total)} · {o.status}{o.tracking_no&&<> · Courier # {o.tracking_no}</>}
   <div className="text-xs text-gray-500">{o.items.map(i=>i.name+' ×'+i.qty).join(', ')}</div>
   <div className="flex gap-1 mt-2">{ST.map((x,i)=><span key={x} className={`flex-1 text-center text-[11px] rounded p-1 ${i<=ST.indexOf(o.status)?'bg-green-600 text-white':'bg-gray-200'}`}>{x}</span>)}</div></div>)}</main>}

const L=({t,children})=><label className="block text-xs font-semibold text-gray-600">{t}{children}</label>;
function Register(){const{setPage,city}=useA();const[st,setSt]=useState(1);const[agree,setAgree]=useState(false);const[otp,setOtp]=useState('');const[busy,setBusy]=useState(false);const[left,setLeft]=useState(0);const[file,setFile]=useState(null);
 const[f,setF]=useState({name:'',email:'',phone:'',city:city||'',address:'',type:'retail',shop_name:'',shop_city:city||'',shop_address:''});
 const u=k=>e=>setF({...f,[k]:e.target.value});const W=f.type==='wholesale',em=f.email.trim().toLowerCase();
 useEffect(()=>{if(left<=0)return;const i=setTimeout(()=>setLeft(left-1),1000);return()=>clearTimeout(i)},[left]);
 const send=async()=>{
  if(f.name.trim().length<3)return alert('Enter your full name');
  if(!/^\S+@\S+\.\S+$/.test(em))return alert('Enter a valid email address');
  if(!/^03\d{9}$/.test(f.phone.replace(/\D/g,'')))return alert('Enter mobile like 03XXXXXXXXX');
  if(!f.city||f.address.trim().length<8)return alert('Enter your city and full address');
  if(W&&(!f.shop_name.trim()||!f.shop_address.trim()||!file))return alert('Shop name, shop address and visiting card are required');
  if(!agree)return alert('Please accept the terms');
  setBusy(true);const{error}=await sb.auth.signInWithOtp({email:em,options:{shouldCreateUser:true,data:{name:f.name}}});setBusy(false);
  error?alert(error.message):(setSt(2),setLeft(60))};
 const resend=async()=>{const{error}=await sb.auth.signInWithOtp({email:em});error?alert(error.message):setLeft(60)};
 const verify=async()=>{setBusy(true);const{data,error}=await sb.auth.verifyOtp({email:em,token:otp.trim(),type:'email'});
  if(error){setBusy(false);return alert(error.message)}
  const uid=data.user.id;let card_url=null;
  if(W){const path=`${uid}/${Date.now()}`;const up=await sb.storage.from('shop-cards').upload(path,file);if(up.error){setBusy(false);return alert(up.error.message)}card_url=sb.storage.from('shop-cards').getPublicUrl(path).data.publicUrl}
  const row={id:uid,full_name:f.name.trim(),email:em,phone:f.phone.replace(/\D/g,''),city:f.city,address:f.address.trim(),type:f.type,status:W?'pending':'approved',...(W?{shop_name:f.shop_name.trim(),shop_city:f.shop_city,shop_address:f.shop_address.trim(),card_url}:{})};
  const{error:e2}=await sb.from('profiles').insert(row);setBusy(false);
  e2?alert(e2.code==='23505'?'This email/account is already registered. Please login.':e2.message):setSt(3)};
 return<main className="max-w-lg mx-auto p-3"><div className="bg-white rounded-2xl shadow p-5 space-y-3">
  <div className="flex items-center gap-2 text-xs font-bold">{['Details','Verify Email','Done'].map((x,i)=><span key={x} className={`flex-1 text-center rounded-full py-1 ${st>i?'bg-green-600 text-white':'bg-gray-200'}`}>{i+1}. {x}</span>)}</div>
  {st===1&&<>
   <h2 className="font-extrabold text-xl text-green-700">Create your DG Bazar account</h2>
   <L t="Full Name"><In value={f.name} onChange={u('name')} placeholder="e.g. Muhammad Ali"/></L>
   <L t="Email (OTP will be sent here)"><In type="email" value={f.email} onChange={u('email')} placeholder="you@email.com"/></L>
   <L t="Mobile Number"><In inputMode="tel" value={f.phone} onChange={u('phone')} placeholder="03XX XXXXXXX"/></L>
   <div className="grid grid-cols-2 gap-2"><L t="City"><select className="w-full border rounded-lg p-2 text-sm" value={f.city} onChange={u('city')}><option value="">Select</option>{CITIES.map(c=><option key={c}>{c}</option>)}</select></L></div>
   <L t="Full Address"><textarea className="w-full border rounded-lg p-2 text-sm" rows={2} value={f.address} onChange={u('address')} placeholder="House / street / area"/></L>
   <div className="space-y-1">{[['retail','Ghar ke liye (Retail Customer)'],['wholesale','Dukan ke liye (Wholesale Shopkeeper)']].map(([k,l])=><label key={k} className={`flex gap-2 border rounded-lg p-2 text-sm ${f.type===k?'border-green-600 bg-green-50':''}`}><input type="radio" checked={f.type===k} onChange={()=>setF({...f,type:k})}/>{l}</label>)}</div>
   {W&&<div className="border rounded-xl p-3 space-y-2 bg-green-50"><b className="text-sm">Shop details</b>
    <L t="Shop Name"><In value={f.shop_name} onChange={u('shop_name')}/></L>
    <L t="Shop City"><select className="w-full border rounded-lg p-2 text-sm" value={f.shop_city} onChange={u('shop_city')}>{CITIES.map(c=><option key={c}>{c}</option>)}</select></L>
    <L t="Shop Address"><In value={f.shop_address} onChange={u('shop_address')}/></L>
    <L t="Shop Visiting Card (photo)"><input type="file" accept="image/*" onChange={e=>setFile(e.target.files[0])}/></L>
    <p className="text-xs text-amber-700">Wholesale prices unlock after admin approves your shop.</p></div>}
   <label className="flex gap-2 text-xs"><input type="checkbox" checked={agree} onChange={e=>setAgree(e.target.checked)}/>I agree to DG Bazar terms and confirm the details are correct.</label>
   <Btn c={G+' w-full'} disabled={busy} onClick={send}>{busy?'Sending...':'Send OTP to my Email'}</Btn>
   <p className="text-xs text-center">Already registered? <button className="text-green-700 underline" onClick={()=>setPage('home')}>Go back & Login</button></p></>}
  {st===2&&<><h2 className="font-extrabold text-xl text-green-700">Check your email ✉️</h2>
   <p className="text-sm">We sent a 6-digit code to <b>{em}</b>. Check Spam/Promotions too.</p>
   <In placeholder="Enter OTP" inputMode="numeric" maxLength={8} value={otp} onChange={e=>setOtp(e.target.value)} className="text-center tracking-widest"/>
   <Btn c={G+' w-full'} disabled={busy||otp.length<6} onClick={verify}>{busy?'Verifying...':'Verify & Create Account'}</Btn>
   <div className="flex justify-between text-xs"><button className="underline" onClick={()=>setSt(1)}>Change email</button><button disabled={left>0} className="underline disabled:text-gray-400" onClick={resend}>{left>0?`Resend in ${left}s`:'Resend OTP'}</button></div></>}
  {st===3&&<div className="text-center space-y-3 py-4"><div className="text-5xl">🎉</div><h2 className="font-extrabold text-xl text-green-700">Account created!</h2>
   <p className="text-sm">{W?'Your shop is under review. Admin will approve it soon — until then you shop at retail prices.':'Welcome to DG Bazar. Happy shopping!'}</p>
   <Btn c={G} onClick={()=>{location.href='/'}}>Start Shopping</Btn></div>}
 </div></main>}

function Install(){const[,f]=useState(0);useEffect(()=>{const h=()=>f(x=>x+1);addEventListener('ipready',h);return()=>removeEventListener('ipready',h)},[]);
 if(matchMedia('(display-mode: standalone)').matches||navigator.standalone)return null;
 const ios=/iphone|ipad|ipod/i.test(navigator.userAgent);
 return<Btn c={G} onClick={async()=>{if(window.__ip){window.__ip.prompt();await window.__ip.userChoice;window.__ip=null;f(x=>x+1)}else alert(ios?'iPhone: tap Share, then "Add to Home Screen".':'Browser menu (⋮) → "Install app" / "Add to Home screen".')}}>⬇ Install App</Btn>}

function Customers(){const[l,setL]=useState([]);const[q,setQ]=useState('');
 const load=()=>sb.from('profiles').select('*').order('created_at',{ascending:false}).limit(200).then(({data})=>setL(data||[]));useEffect(()=>{load()},[]);
 const upd=async(id,p)=>{const{error}=await sb.from('profiles').update(p).eq('id',id);error?alert(error.message):load()};
 const f=l.filter(p=>[p.full_name,p.email,p.phone,p.shop_name].join(' ').toLowerCase().includes(q.toLowerCase()));
 return<div><In placeholder="Search name / email / phone" value={q} onChange={e=>setQ(e.target.value)}/>
  <div className="bg-white rounded-xl overflow-x-auto mt-2"><table className="w-full text-sm"><tbody>{f.map(p=><tr key={p.id} className="border-b"><td className="p-2"><b>{p.full_name||'-'}</b>{p.role==='admin'&&' 👑'}<br/><span className="text-xs text-gray-500">{p.email} · {p.phone}</span></td>
   <td className="text-xs">{p.type}<br/>{p.shop_name}</td><td className="text-xs">{p.status}{p.blocked&&' 🚫'}</td>
   <td>{p.type==='wholesale'&&p.status!=='approved'&&<Btn c={G} onClick={()=>upd(p.id,{status:'approved'})}>Approve</Btn>}{p.role!=='admin'&&<Btn c="text-red-600" onClick={()=>upd(p.id,{blocked:!p.blocked})}>{p.blocked?'Unblock':'Block'}</Btn>}</td></tr>)}</tbody></table></div></div>}
function Coupons(){const[l,setL]=useState([]);const[c,setC]=useState({code:'',kind:'flat',value:''});
 const load=()=>sb.from('coupons').select('*').then(({data})=>setL(data||[]));useEffect(()=>{load()},[]);
 const add=async()=>{const{error}=await sb.from('coupons').insert({code:c.code.trim().toUpperCase(),kind:c.kind,value:+c.value,max:300,active:true});error?alert(error.message):(setC({code:'',kind:'flat',value:''}),load())};
 return<div className="space-y-2"><div className="bg-white rounded-xl p-3 space-y-1"><In placeholder="CODE e.g. EID100" value={c.code} onChange={e=>setC({...c,code:e.target.value})}/>
  <div className="flex gap-2"><select className="border rounded-lg p-2 text-sm" value={c.kind} onChange={e=>setC({...c,kind:e.target.value})}><option value="flat">Rs. off</option><option value="pct">% off</option></select><In type="number" placeholder="Value" value={c.value} onChange={e=>setC({...c,value:e.target.value})}/></div><Btn c={G} onClick={add}>Add coupon</Btn></div>
  {l.map(x=><div key={x.code} className="bg-white rounded-xl p-3 flex items-center text-sm"><b className="flex-1">{x.code} · {x.kind==='flat'?'Rs. '+x.value:x.value+'%'}</b><Btn c={x.active?'border':G} onClick={async()=>{await sb.from('coupons').update({active:!x.active}).eq('code',x.code);load()}}>{x.active?'Disable':'Enable'}</Btn></div>)}</div>}
function Activity(){const[l,setL]=useState([]);useEffect(()=>{sb.from('admin_log').select('*').order('id',{ascending:false}).limit(50).then(({data})=>setL(data||[]))},[]);
 return<div className="bg-white rounded-xl p-3 text-xs space-y-1">{!l.length&&'No activity yet'}{l.map(x=><div key={x.id}>{new Date(x.at).toLocaleString()} · <b>{x.action}</b> · {x.detail}</div>)}</div>}
