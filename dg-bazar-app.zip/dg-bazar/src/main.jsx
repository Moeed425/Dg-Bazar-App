import{createRoot}from'react-dom/client';import'./index.css';import App from'./App.jsx';
createRoot(document.getElementById('root')).render(<App/>);

addEventListener('beforeinstallprompt',e=>{e.preventDefault();window.__ip=e;dispatchEvent(new Event('ipready'))});
if('serviceWorker' in navigator&&import.meta.env.PROD)addEventListener('load',()=>navigator.serviceWorker.register('/sw.js'));
