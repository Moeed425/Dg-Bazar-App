import{createRoot}from'react-dom/client';import'./index.css';import App from'./App.jsx';
createRoot(document.getElementById('root')).render(<App/>);

addEventListener('beforeinstallprompt',e=>{e.preventDefault();window.__ip=e;dispatchEvent(new Event('ipready'))});
if('serviceWorker' in navigator&&import.meta.env.PROD)addEventListener('load',()=>navigator.serviceWorker.register(import.meta.env.BASE_URL+'sw.js'));

window.applyTheme=()=>{const t=localStorage.theme,d=t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches);document.documentElement.classList.toggle('dark',d);document.querySelector('meta[name=theme-color]')?.setAttribute('content',d?'#0f1511':'#16a34a')};
window.toggleTheme=()=>{localStorage.theme=document.documentElement.classList.contains('dark')?'light':'dark';window.applyTheme()};
window.applyTheme();matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>{if(!localStorage.theme)window.applyTheme()});

window.fontStep=d=>{const v=Math.min(140,Math.max(80,(+localStorage.fs||100)+d*10));localStorage.fs=v;document.documentElement.style.fontSize=v+'%'};
document.documentElement.style.fontSize=(+localStorage.fs||100)+'%';
