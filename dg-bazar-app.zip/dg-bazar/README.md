# DG Bazar — production setup
1. Supabase → SQL editor: run `supabase/schema.sql`, then `supabase/002_production.sql`.
2. Auth → Providers → Phone: enable + connect Twilio (or MessageBird/Vonage). Set OTP expiry 300s.
3. Admin = phone 03158120199 (stored as 923158120199). Log in at `/admin` with OTP — the role is set by a DB trigger from the verified phone, never by the client.
4. `cp .env.example .env` (URL, anon key, WhatsApp number) → `npm i && npm run dev`.
5. Deploy: push to GitHub → import in Vercel (add the 3 env vars; `vercel.json` handles /admin routing).
Security model: prices, stock, delivery, coupons are computed in `place_order()`; the browser cannot set them. Orders are private per user (RLS). Orders require login.

## Email OTP (registration)
1. Run `supabase/003_registration.sql`.
2. Auth → Providers → Email: enable; keep "Confirm email" ON; OTP length 6, expiry 600s.
3. Auth → Email Templates → paste `supabase/email-otp-template.html` into **Confirm signup** AND **Magic Link** (it must contain `{{ .Token }}` or users get a link instead of a code).
4. Auth → SMTP Settings: add your own SMTP (Resend / Brevo / Gmail app password). Supabase's built-in mailer is limited to a few emails per hour and is not for production.
5. Admin by email: change `amoeed021@gmail.com` in 003_registration.sql to a mailbox you own, then register with it.

## Install as an app (PWA + Android APK)
**Phone install (no Play Store):** deploy to Vercel (HTTPS required) → open the site in Chrome → tap **⬇ Install App** (iPhone: Share → Add to Home Screen). It gets a home-screen icon, full-screen mode, and opens the cached shell offline.
**Android APK / Play Store (Capacitor):**
```
npm i @capacitor/core @capacitor/cli @capacitor/android
npm run build && npx cap add android && npx cap sync
npx cap open android   # Android Studio → Build → Build APK(s)
```
App id is `pk.dgbazar.app` (edit `capacitor.config.json`). Note: Supabase Auth → URL config must allow your site URL.

## Get the APK (no Android Studio needed)
1. Create a GitHub repo, upload this project (branch `main`).
2. Repo → Settings → Secrets and variables → Actions → add `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_WHATSAPP`.
3. Actions tab → **Build Android APK** → Run workflow (~5 min).
4. Open the finished run → Artifacts → download **DG-Bazar-APK** → unzip → `app-debug.apk`.
5. Send it to your phone, tap it, allow "Install unknown apps". (Play Store needs a signed release build + $25 developer account.)
